import React from 'react';
import { useNavigate } from "react-router-dom";
import Login from './login';
const ResetPassword = () => {
    var navigate = useNavigate()
    const handleClick = () => {
        navigate("/");
    };
    return (
        <div className="form-membership">
            <div className="form-wrapper">
                {/* <!-- logo --> */}
                <div id="logo">
                    <h2>PropTech</h2>
                </div>
                {/* <!-- ./ logo --> */}
                <h5>Reset password</h5>

                {/* <!-- form --> */}
                <form>
                    <div className="form-group mb-3">
                        <input type="text" className="form-control" placeholder="Username or email" required autofocus />
                    </div>
                    <button className="btn btn-primary btn-block mb-3">Submit</button>
                    <hr/>
                    {/* <p className="text-muted">Take a different action.</p>

                    <a href="./register.html" className="btn btn-sm btn-outline-light mr-1" style={{ display: "flex", justifyContent: "center", alignItems: 'center' }}>Register now!</a>
                    <span style={{ display: "flex", justifyContent: "center", alignItems: 'center' }}>or</span> */}
                    <a href="" className="btn btn-sm btn-outline-light ml-1" style={{ display: "flex", justifyContent: "center", alignItems: 'center' }} onClick={()=>handleClick()} >Login!</a>
                </form>
                {/* <!-- ./ form --> */}

            </div>


        </div>

    );
}

export default ResetPassword;
