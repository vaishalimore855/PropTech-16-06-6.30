import React from "react";
import logo from "../../assets/media/image/logo.png";
import logo_sm from "../../assets/media/image/logo-sm.png";
import logo_dark from "../../assets/media/image/logo-dark.png";
//icons
import "bootstrap/dist/css/bootstrap.min.css";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faSearch, faUser } from "@fortawesome/free-solid-svg-icons";
import { faCog } from "@fortawesome/free-solid-svg-icons";
import { faSignOutAlt } from "@fortawesome/free-solid-svg-icons";
import { faBars } from "@fortawesome/free-solid-svg-icons/faBars";
import { faExpand } from "@fortawesome/free-solid-svg-icons/faExpand";
import { faTh, faThLarge } from "@fortawesome/free-solid-svg-icons";
import { faComment } from "@fortawesome/free-solid-svg-icons";
import { faBell } from "@fortawesome/free-solid-svg-icons";
import { useNavigate } from "react-router-dom";
import Header from "../admin/Header";
const Sidebar = () => {
  var navigate1 = useNavigate();
  const handleClick1 = () => {
    navigate1("/profile");
  };
  var navigate2 = useNavigate();
  const handleClick2 = () => {
    navigate2("/sweetalert");
  };
  var navigate3 = useNavigate();
  const handleClick3 = () => {
    navigate3("/add-buyer");
  };
  return (
    <>
      {/* <!-- begin::navigation --> */}
      <div
        className="navigation"
        style={{ overflow: "auto", height: "100vh", position: "fixed" }}
      >
        {/* <!-- begin::logo --> */}
        <div id="logo">
          <a href="index.html">
            <img className="logo" src={logo} alt="logo" />
            {/* <img className="logo-sm" src={logo_sm} alt="small logo" />
            <img className="logo-dark" src={logo_dark} alt="dark logo" /> */}
          </a>
        </div>
        {/* <!-- end::logo --> */}

        {/* <!-- begin::navigation header --> */}
        <header className="navigation-header">
          <figure className="avatar avatar-state-success">
            <img
              src="https://via.placeholder.com/128X128"
              className="rounded-circle"
              alt="image"
            />
          </figure>
          <div>
            <h5>Nikos Pedlow</h5>
            <p className="text-muted">Administrator</p>
            <ul className="nav">
              <li className="nav-item">
                <a
                  href="profile.html"
                  className="btn nav-link bg-info-bright"
                  title="Profile"
                  data-toggle="tooltip"
                >
                  {/* <i data-feather="user"></i> */}
                  <FontAwesomeIcon icon={faUser} />
                </a>
              </li>
              <li className="nav-item">
                <a
                  href="#"
                  className="btn nav-link bg-success-bright"
                  title="Settings"
                  data-toggle="tooltip"
                >
                  {/* <i data-feather="settings"></i> */}
                  <FontAwesomeIcon icon={faCog} />
                </a>
              </li>
              <li className="nav-item">
                <a
                  href="login.html"
                  className="btn nav-link bg-danger-bright"
                  title="Logout"
                  data-toggle="tooltip"
                >
                  {/* <i data-feather="log-out"></i> */}
                  <FontAwesomeIcon icon={faSignOutAlt} />
                </a>
              </li>
            </ul>
          </div>
        </header>
        {/* end::navigation header  */}

        {/* begin::navigation menu  */}
        <div className="navigation-menu-body">
          <ul>
            
            <li className="navigation-divider">Extras</li>
            <li>
              <a href="#">
                <i className="nav-link-icon" data-feather="user"></i>
                <span>Authentication</span>
              </a>
              <ul>
                <li>
                  <a href="login.html">Login</a>
                </li>
                <li>
                  <a href="register.html">Register</a>
                </li>
                <li>
                  <a href="recover-password.html">Recovery Password</a>
                </li>
                <li>
                  <a href="lock-screen.html">Lock Screen</a>
                </li>
              </ul>
            </li>
            <li className="open">
              <a href="#">
                <i className="nav-link-icon" data-feather="copy"></i>
                <span>Pages</span>
              </a>
              <ul>
                <li>
                  <a className="active" href="" onClick={() => handleClick1()}>
                    Profile
                  </a>
                </li>
                <li>
                  {/* <a href="timeline.html">Timeline</a> */}
                  <a className="active" href="" onClick={() => handleClick2()}>
                    Sweet Alert
                  </a>
                </li>
                <li>
                  {/* <a href="invoice.html">Invoice</a> */}
                  <a className="active" href="" onClick={() => handleClick3()}>
                    Add Buyer
                  </a>
                </li>

                <li>
                  <a href="pricing-table.html">Pricing Table</a>
                </li>
                <li>
                  <a href="search-result.html">Search Result</a>
                </li>
                <li>
                  <a href="#">Error Pages</a>
                  <ul>
                    <li>
                      <a href="404.html">404</a>
                    </li>
                    <li>
                      <a href="404-2.html">404 V2</a>
                    </li>
                    <li>
                      <a href="503.html">503</a>
                    </li>
                    <li>
                      <a href="mean-at-work.html">Mean at Work</a>
                    </li>
                  </ul>
                </li>
                <li>
                  <a href="blank-page.html">Starter Page</a>
                </li>
              </ul>
            </li>
            <li>
              <a href="#">
                <i className="nav-link-icon" data-feather="send"></i>
                <span>Email Templates</span>
              </a>
              <ul>
                <li>
                  <a href="email-template-basic.html">Basic</a>
                </li>
                <li>
                  <a href="email-template-alert.html">Alert</a>
                </li>
                <li>
                  <a href="email-template-billing.html">Billing</a>
                </li>
              </ul>
            </li>
            <li>
              <a href="#">
                <i className="nav-link-icon" data-feather="menu"></i>
                <span>Menu Level</span>
              </a>
              <ul>
                <li>
                  <a href="#">Menu Level</a>
                  <ul>
                    <li>
                      <a href="#">Menu Level </a>
                    </li>
                  </ul>
                </li>
              </ul>
            </li>
          </ul>
        </div>
        {/* end::navigation menu  */}
      </div>
      {/* end::navigation  */}
      <div  id="main">
         <Header/>
      </div>
    </>
  );
};

export default Sidebar;

