import React from 'react';
const AddBuyer = () => {
    return (
        <div className="rtl">
            <div id="main" >
                <div className="main-content">
                    <div className="container">
                        {/* <!-- begin::page-header --> */}
                        <div className="page-header">
                            <h4>Add Buyer</h4>
                            <nav aria-label="breadcrumb">
                                <ol className="breadcrumb">
                                    <li className="breadcrumb-item">
                                        <a href="#">Home</a>
                                    </li>
                                    <li className="breadcrumb-item">
                                        <a href="#">User Management Screen</a>
                                    </li>
                                    <li className="breadcrumb-item">
                                        <a href="#">Buyers</a>
                                    </li>
                                    <li className="breadcrumb-item active" aria-current="page">Add Buyer</li>
                                </ol>
                            </nav>
                        </div>
                        {/* <!-- end::page-header --> */}

                        <div className="row">
                            <div className="col-md-12">
                                <div className="card">
                                    <div className="card-body">
                                        <form className="needs-validation" novalidate="">
                                            <div className="form-row">
                                                <div className="col-md-4 mb-3">
                                                    <label for="validationCustom01">Full Name</label>
                                                    <input type="text" className="form-control" id="validationCustom01" placeholder="enter your full name"
                                                        required="" />
                                                    <div className="valid-feedback">
                                                        Looks good!
                                                    </div>
                                                </div>
                                                <div className="col-md-4 mb-3">
                                                    <label for="validationCustom02">Contact Number</label>
                                                    <input type="text" data-input-mask="phone" className="form-control" id="validationCustom02" placeholder="9087654321" required="" />
                                                    <div className="valid-feedback">
                                                        Looks good!
                                                    </div>
                                                </div>
                                                <div className="col-md-4 mb-3">
                                                    <label for="validationCustom03">Budget</label>
                                                    <input type="text" className="form-control" id="validationCustom03" placeholder="enter your Budget" required="" />
                                                    <div className="valid-feedback">
                                                        Looks good!
                                                    </div>
                                                </div>

                                            </div>
                                            <div className="form-row">
                                                <div className="col-md-6 mb-3">
                                                    <label for="validationCustom04">Location Preferences</label>
                                                    <input type="text" className="form-control" id="validationCustom04" placeholder=""
                                                        required="" />
                                                    <div className="invalid-feedback">
                                                        Please provide a valid location.
                                                    </div>
                                                </div>
                                                <div className="col-md-3 mb-3">
                                                    <label for="validationCustom04">Property Type</label>
                                                    <select className="select2-example">
                                                        <option>Select</option>
                                                        <option value="House">House</option>
                                                        <option value="Apartment">Apartment</option>
                                                        <option value="Land">Land</option>
                                                    </select>
                                                    <div className="invalid-feedback">

                                                    </div>
                                                </div>
                                                <div className="col-md-3 mb-3">
                                                    <label for="validationCustom06">Preferred Square Footage</label>
                                                    <input type="text" className="form-control" id="validationCustom06" placeholder="" required="" />
                                                    <div className="invalid-feedback">

                                                    </div>
                                                </div>
                                                <div className="col-md-6 mb-3">
                                                    <label for="validationCustom05">Amenities</label>
                                                    <textarea className="form-control" id="validationCustom05" rows="3"></textarea>

                                                    {/* <!-- <input type="text" className="form-control" id="validationCustom05" placeholder="enter amenities"required=""/> --> */}
                                                    <div className="invalid-feedback">

                                                    </div>
                                                </div>
                                                <div className="col-md-6 mb-3">
                                                    <label for="validationCustom07">Preferred Neighborhood Features</label>
                                                    <textarea className="form-control" id="validationCustom07" rows="3"></textarea>
                                                    <div className="invalid-feedback">

                                                    </div>
                                                </div>
                                                <div className="col-md-3 mb-3">
                                                    <label for="validationCustom08">Financing</label>
                                                    <select className="select2-example">
                                                        <option value="Cash">Cash</option>
                                                        <option value=" Mortgage"> Mortgage</option>
                                                        <option value="Other Options">Other Options</option>
                                                    </select>
                                                    <div className="invalid-feedback">

                                                    </div>
                                                </div>
                                                <div className="col-md-6 mb-3">
                                                    <label for="validationCustom09">Additional Comments/Notes</label>
                                                    <textarea className="form-control" id="validationCustom09" rows="3"></textarea>
                                                    <div className="invalid-feedback">

                                                    </div>
                                                </div>
                                            </div>
                                            <div className="form-group">
                                                <div className="form-check">
                                                    <input className="form-check-input" type="checkbox" value="" id="invalidCheck" required="" />
                                                    <label className="form-check-label" for="invalidCheck">
                                                        Agree to terms and conditions
                                                    </label>
                                                    <div className="invalid-feedback">
                                                        You must agree before submitting.
                                                    </div>
                                                </div>
                                            </div>
                                            <button className="btn btn-primary" type="submit">Submit </button>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>

                </div>
                {/* <!-- end::main-content --> */}
            </div>
            {/* <!-- end::main --> */}

            {/* <!-- Plugin scripts --> */}
            <script src="vendors/bundle.js"></script>

            {/* // <!-- Chartjs --> */}
            <script src="vendors/charts/chartjs/chart.min.js"></script>

            {/* <!-- Apex chart --> */}
            <script src="vendors/charts/apex/apexcharts.min.js"></script>

            {/* <!-- Circle progress --> */}
            <script src="vendors/circle-progress/circle-progress.min.js"></script>

            {/* <!-- Peity --> */}
            <script src="vendors/charts/peity/jquery.peity.min.js"></script>
            <script src="assets/js/examples/charts/peity.js"></script>

            {/* <!-- Datepicker --> */}
            <script src="vendors/datepicker/daterangepicker.js"></script>

            {/* <!-- Slick --> */}
            <script src="vendors/slick/slick.min.js"></script>

            {/* <!-- Vamp --> */}
            <script src="vendors/vmap/jquery.vmap.min.js"></script>
            <script src="vendors/vmap/maps/jquery.vmap.usa.js"></script>
            <script src="assets/js/examples/vmap.js"></script>

            {/* <!-- Dashboard scripts --> */}
            <script src="assets/js/examples/dashboard.js"></script>
            <div className="colors">
                {/* <!-- To use theme colors with Javascript --> */}
                <div className="bg-primary"></div>
                <div className="bg-primary-bright"></div>
                <div className="bg-secondary"></div>
                <div className="bg-secondary-bright"></div>
                <div className="bg-info"></div>
                <div className="bg-info-bright"></div>
                <div className="bg-success"></div>
                <div className="bg-success-bright"></div>
                <div className="bg-danger"></div>
                <div className="bg-danger-bright"></div>
                <div className="bg-warning"></div>
                <div className="bg-warning-bright"></div>
            </div>

            {/* <!-- Javascript --> */}
            <script src="vendors/select2/js/select2.min.js"></script>

            {/* <!-- App scripts --> */}
            <script src="assets/js/app.min.js"></script>

            <script src="vendors/input-mask/jquery.mask.js"></script>

            {/* <script>
                $('[data-input-mask="phone"]').mask('0000000000');

                $('.select2-example').select2({
                    placeholder = 'Select'
                });
            </script> */}
        </div>
    );
}

export default AddBuyer;
