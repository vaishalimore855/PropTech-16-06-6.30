import React from "react";
import { useNavigate } from "react-router-dom";
//icons
import "bootstrap/dist/css/bootstrap.min.css";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faEye } from "@fortawesome/free-solid-svg-icons";
import { faPencilSquare } from "@fortawesome/free-solid-svg-icons";
import { faTrash, faTrashAlt } from "@fortawesome/free-solid-svg-icons";

function Investors() {
  var navigate = useNavigate();

  const handleClick = () => {
    navigate("/add-investor");
  };

  return (
    <>
      {/* <!-- begin::main --> */}
      <div id="main">
        {/* <!-- begin::main-content --> */}
        <main className="main-content">
          <div className="container">
            {/* <!-- begin::page-header --> */}
            <div className="page-header">
              <h4>Investors</h4>
              <nav aria-label="breadcrumb">
                <ol className="breadcrumb">
                  <li className="breadcrumb-item">
                    <a href="#">Home</a>
                  </li>
                  <li className="breadcrumb-item">
                    <a href="#">User Management Screen</a>
                  </li>
                  <li className="breadcrumb-item active" aria-current="page">
                    Investors
                  </li>
                </ol>
              </nav>
            </div>
            {/* <!-- end::page-header --> */}

            <div className="row">
              <div className="col-md-12">
                <div className="card">
                  <div className="card-body">
                    <div className="pt-4 pb-4 text-left">
                      <button
                        type="button"
                        className="btn btn-primary btn-rounded  "
                      >
                        <a
                          href=""
                          className="text-white"
                          onClick={() => handleClick()}
                        >
                          + Add Investor
                        </a>
                      </button>
                    </div>

                    <div className="card">
                      <div className="card-body">
                        <table
                          id="example2"
                          className="table table-striped table-bordered"
                        >
                          <thead>
                            <tr>
                              <th>ID</th>
                              <th>Name</th>
                              <th>Contact</th>
                              <th>Budget</th>
                              <th>Preferred Location</th>
                              <th>Property Type</th>
                              <th>Actions</th>
                            </tr>
                          </thead>
                          <tbody>
                            <tr>
                              <td>1</td>
                              <td>Tiger Nixon</td>
                              <td>System Architect</td>
                              <td>Edinburgh</td>
                              <td>61</td>
                              <td>2011/04/25</td>
                              <td className="d-flex">
                                <a
                                  href=""
                                  className="btn btn-sm btn-icon me-2  float-left btn-info"
                                  data-toggle="tooltip"
                                  data-placement="top"
                                  title=""
                                  data-original-title="View"
                                >
                                  {" "}
                                  <FontAwesomeIcon
                                    icon={faEye}
                                    style={{ color: "white" }}
                                  />
                                </a>
                                <a
                                  href=""
                                  className="btn btn-sm btn-icon float-left btn-primary me-2"
                                  data-toggle="tooltip"
                                  data-placement="top"
                                  title=""
                                  data-original-title="Edit"
                                >
                                  {" "}
                                  <FontAwesomeIcon
                                    icon={faPencilSquare}
                                    style={{ color: "white" }}
                                  />
                                </a>
                                <form
                                  className="float-left pl-2"
                                  action="https://fit-buddy.io/admin/admin/menu-items/1615"
                                  method="POST"
                                >
                                  <input
                                    type="hidden"
                                    name="_method"
                                    value="DELETE"
                                  />
                                  <input
                                    type="hidden"
                                    name="_token"
                                    value="C4KWMkgrCT3CJNo8uJLXYiLCgDcL5LvFf7KFfBul"
                                  />
                                  <button
                                    className="btn btn-sm btn-icon btn-danger me-2"
                                    data-toggle="tooltip"
                                    data-placement="top"
                                    title=""
                                    data-original-title="Delete"
                                  >
                                    {" "}
                                    <FontAwesomeIcon
                                      icon={faTrashAlt}
                                      style={{ color: "white" }}
                                    />
                                  </button>
                                </form>
                              </td>
                            </tr>
                            <tr>
                              <td>2</td>
                              <td>Garrett Winters</td>
                              <td>Accountant</td>
                              <td>Tokyo</td>
                              <td>63</td>
                              <td>2011/07/25</td>
                              <td className="d-flex">
                                <a
                                  href=""
                                  className="btn btn-sm btn-icon me-2  float-left btn-info"
                                  data-toggle="tooltip"
                                  data-placement="top"
                                  title=""
                                  data-original-title="View"
                                >
                                  {" "}
                                  <FontAwesomeIcon
                                    icon={faEye}
                                    style={{ color: "white" }}
                                  />
                                </a>
                                <a
                                  href=""
                                  className="btn btn-sm btn-icon float-left btn-primary me-2"
                                  data-toggle="tooltip"
                                  data-placement="top"
                                  title=""
                                  data-original-title="Edit"
                                >
                                  {" "}
                                  <FontAwesomeIcon
                                    icon={faPencilSquare}
                                    style={{ color: "white" }}
                                  />
                                </a>
                                <form
                                  className="float-left pl-2"
                                  action="https://fit-buddy.io/admin/admin/menu-items/1615"
                                  method="POST"
                                >
                                  <input
                                    type="hidden"
                                    name="_method"
                                    value="DELETE"
                                  />
                                  <input
                                    type="hidden"
                                    name="_token"
                                    value="C4KWMkgrCT3CJNo8uJLXYiLCgDcL5LvFf7KFfBul"
                                  />
                                  <button
                                    className="btn btn-sm btn-icon btn-danger me-2"
                                    data-toggle="tooltip"
                                    data-placement="top"
                                    title=""
                                    data-original-title="Delete"
                                  >
                                    {" "}
                                    <FontAwesomeIcon
                                      icon={faTrashAlt}
                                      style={{ color: "white" }}
                                    />
                                  </button>
                                </form>
                              </td>
                            </tr>
                            <tr>
                              <td>3</td>
                              <td>Ashton Cox</td>
                              <td>Junior Technical Author</td>
                              <td>San Francisco</td>
                              <td>66</td>
                              <td>2009/01/12</td>
                              <td className="d-flex">
                                <a
                                  href=""
                                  className="btn btn-sm btn-icon me-2  float-left btn-info"
                                  data-toggle="tooltip"
                                  data-placement="top"
                                  title=""
                                  data-original-title="View"
                                >
                                  {" "}
                                  <FontAwesomeIcon
                                    icon={faEye}
                                    style={{ color: "white" }}
                                  />
                                </a>
                                <a
                                  href=""
                                  className="btn btn-sm btn-icon float-left btn-primary me-2"
                                  data-toggle="tooltip"
                                  data-placement="top"
                                  title=""
                                  data-original-title="Edit"
                                >
                                  {" "}
                                  <FontAwesomeIcon
                                    icon={faPencilSquare}
                                    style={{ color: "white" }}
                                  />
                                </a>
                                <form
                                  className="float-left pl-2"
                                  action="https://fit-buddy.io/admin/admin/menu-items/1615"
                                  method="POST"
                                >
                                  <input
                                    type="hidden"
                                    name="_method"
                                    value="DELETE"
                                  />
                                  <input
                                    type="hidden"
                                    name="_token"
                                    value="C4KWMkgrCT3CJNo8uJLXYiLCgDcL5LvFf7KFfBul"
                                  />
                                  <button
                                    className="btn btn-sm btn-icon btn-danger me-2"
                                    data-toggle="tooltip"
                                    data-placement="top"
                                    title=""
                                    data-original-title="Delete"
                                  >
                                    {" "}
                                    <FontAwesomeIcon
                                      icon={faTrashAlt}
                                      style={{ color: "white" }}
                                    />
                                  </button>
                                </form>
                              </td>
                            </tr>
                            <tr>
                              <td>4</td>
                              <td>Cedric Kelly</td>
                              <td>Senior Javascript Developer</td>
                              <td>Edinburgh</td>
                              <td>22</td>
                              <td>2012/03/29</td>
                              <td className="d-flex">
                                <a
                                  href=""
                                  className="btn btn-sm btn-icon me-2  float-left btn-info"
                                  data-toggle="tooltip"
                                  data-placement="top"
                                  title=""
                                  data-original-title="View"
                                >
                                  {" "}
                                  <FontAwesomeIcon
                                    icon={faEye}
                                    style={{ color: "white" }}
                                  />
                                </a>
                                <a
                                  href=""
                                  className="btn btn-sm btn-icon float-left btn-primary me-2"
                                  data-toggle="tooltip"
                                  data-placement="top"
                                  title=""
                                  data-original-title="Edit"
                                >
                                  {" "}
                                  <FontAwesomeIcon
                                    icon={faPencilSquare}
                                    style={{ color: "white" }}
                                  />
                                </a>
                                <form
                                  className="float-left pl-2"
                                  action="https://fit-buddy.io/admin/admin/menu-items/1615"
                                  method="POST"
                                >
                                  <input
                                    type="hidden"
                                    name="_method"
                                    value="DELETE"
                                  />
                                  <input
                                    type="hidden"
                                    name="_token"
                                    value="C4KWMkgrCT3CJNo8uJLXYiLCgDcL5LvFf7KFfBul"
                                  />
                                  <button
                                    className="btn btn-sm btn-icon btn-danger me-2"
                                    data-toggle="tooltip"
                                    data-placement="top"
                                    title=""
                                    data-original-title="Delete"
                                  >
                                    {" "}
                                    <FontAwesomeIcon
                                      icon={faTrashAlt}
                                      style={{ color: "white" }}
                                    />
                                  </button>
                                </form>
                              </td>
                            </tr>
                            <tr>
                              <td>5</td>
                              <td>Airi Satou</td>
                              <td>Accountant</td>
                              <td>Tokyo</td>
                              <td>33</td>
                              <td>2008/11/28</td>
                              <td className="d-flex">
                                <a
                                  href=""
                                  className="btn btn-sm btn-icon me-2  float-left btn-info"
                                  data-toggle="tooltip"
                                  data-placement="top"
                                  title=""
                                  data-original-title="View"
                                >
                                  {" "}
                                  <FontAwesomeIcon
                                    icon={faEye}
                                    style={{ color: "white" }}
                                  />
                                </a>
                                <a
                                  href=""
                                  className="btn btn-sm btn-icon float-left btn-primary me-2"
                                  data-toggle="tooltip"
                                  data-placement="top"
                                  title=""
                                  data-original-title="Edit"
                                >
                                  {" "}
                                  <FontAwesomeIcon
                                    icon={faPencilSquare}
                                    style={{ color: "white" }}
                                  />
                                </a>
                                <form
                                  className="float-left pl-2"
                                  action="https://fit-buddy.io/admin/admin/menu-items/1615"
                                  method="POST"
                                >
                                  <input
                                    type="hidden"
                                    name="_method"
                                    value="DELETE"
                                  />
                                  <input
                                    type="hidden"
                                    name="_token"
                                    value="C4KWMkgrCT3CJNo8uJLXYiLCgDcL5LvFf7KFfBul"
                                  />
                                  <button
                                    className="btn btn-sm btn-icon btn-danger me-2"
                                    data-toggle="tooltip"
                                    data-placement="top"
                                    title=""
                                    data-original-title="Delete"
                                  >
                                    {" "}
                                    <FontAwesomeIcon
                                      icon={faTrashAlt}
                                      style={{ color: "white" }}
                                    />
                                  </button>
                                </form>
                              </td>
                            </tr>
                            <tr>
                              <td>6</td>
                              <td>Brielle Williamson</td>
                              <td>Integration Specialist</td>
                              <td>New York</td>
                              <td>61</td>
                              <td>2012/12/02</td>
                              <td className="d-flex">
                                <a
                                  href=""
                                  className="btn btn-sm btn-icon me-2  float-left btn-info"
                                  data-toggle="tooltip"
                                  data-placement="top"
                                  title=""
                                  data-original-title="View"
                                >
                                  {" "}
                                  <FontAwesomeIcon
                                    icon={faEye}
                                    style={{ color: "white" }}
                                  />
                                </a>
                                <a
                                  href=""
                                  className="btn btn-sm btn-icon float-left btn-primary me-2"
                                  data-toggle="tooltip"
                                  data-placement="top"
                                  title=""
                                  data-original-title="Edit"
                                >
                                  {" "}
                                  <FontAwesomeIcon
                                    icon={faPencilSquare}
                                    style={{ color: "white" }}
                                  />
                                </a>
                                <form
                                  className="float-left pl-2"
                                  action="https://fit-buddy.io/admin/admin/menu-items/1615"
                                  method="POST"
                                >
                                  <input
                                    type="hidden"
                                    name="_method"
                                    value="DELETE"
                                  />
                                  <input
                                    type="hidden"
                                    name="_token"
                                    value="C4KWMkgrCT3CJNo8uJLXYiLCgDcL5LvFf7KFfBul"
                                  />
                                  <button
                                    className="btn btn-sm btn-icon btn-danger me-2"
                                    data-toggle="tooltip"
                                    data-placement="top"
                                    title=""
                                    data-original-title="Delete"
                                  >
                                    {" "}
                                    <FontAwesomeIcon
                                      icon={faTrashAlt}
                                      style={{ color: "white" }}
                                    />
                                  </button>
                                </form>
                              </td>
                            </tr>
                            <tr>
                              <td>7</td>
                              <td>Herrod Chandler</td>
                              <td>Sales Assistant</td>
                              <td>San Francisco</td>
                              <td>59</td>
                              <td>2012/08/06</td>
                              <td className="d-flex">
                                <a
                                  href=""
                                  className="btn btn-sm btn-icon me-2  float-left btn-info"
                                  data-toggle="tooltip"
                                  data-placement="top"
                                  title=""
                                  data-original-title="View"
                                >
                                  {" "}
                                  <FontAwesomeIcon
                                    icon={faEye}
                                    style={{ color: "white" }}
                                  />
                                </a>
                                <a
                                  href=""
                                  className="btn btn-sm btn-icon float-left btn-primary me-2"
                                  data-toggle="tooltip"
                                  data-placement="top"
                                  title=""
                                  data-original-title="Edit"
                                >
                                  {" "}
                                  <FontAwesomeIcon
                                    icon={faPencilSquare}
                                    style={{ color: "white" }}
                                  />
                                </a>
                                <form
                                  className="float-left pl-2"
                                  action="https://fit-buddy.io/admin/admin/menu-items/1615"
                                  method="POST"
                                >
                                  <input
                                    type="hidden"
                                    name="_method"
                                    value="DELETE"
                                  />
                                  <input
                                    type="hidden"
                                    name="_token"
                                    value="C4KWMkgrCT3CJNo8uJLXYiLCgDcL5LvFf7KFfBul"
                                  />
                                  <button
                                    className="btn btn-sm btn-icon btn-danger me-2"
                                    data-toggle="tooltip"
                                    data-placement="top"
                                    title=""
                                    data-original-title="Delete"
                                  >
                                    {" "}
                                    <FontAwesomeIcon
                                      icon={faTrashAlt}
                                      style={{ color: "white" }}
                                    />
                                  </button>
                                </form>
                              </td>
                            </tr>
                            <tr>
                              <td>8</td>
                              <td>Rhona Davidson</td>
                              <td>Integration Specialist</td>
                              <td>Tokyo</td>
                              <td>55</td>
                              <td>2010/10/14</td>
                              <td className="d-flex">
                                <a
                                  href=""
                                  className="btn btn-sm btn-icon me-2  float-left btn-info"
                                  data-toggle="tooltip"
                                  data-placement="top"
                                  title=""
                                  data-original-title="View"
                                >
                                  {" "}
                                  <FontAwesomeIcon
                                    icon={faEye}
                                    style={{ color: "white" }}
                                  />
                                </a>
                                <a
                                  href=""
                                  className="btn btn-sm btn-icon float-left btn-primary me-2"
                                  data-toggle="tooltip"
                                  data-placement="top"
                                  title=""
                                  data-original-title="Edit"
                                >
                                  {" "}
                                  <FontAwesomeIcon
                                    icon={faPencilSquare}
                                    style={{ color: "white" }}
                                  />
                                </a>
                                <form
                                  className="float-left pl-2"
                                  action="https://fit-buddy.io/admin/admin/menu-items/1615"
                                  method="POST"
                                >
                                  <input
                                    type="hidden"
                                    name="_method"
                                    value="DELETE"
                                  />
                                  <input
                                    type="hidden"
                                    name="_token"
                                    value="C4KWMkgrCT3CJNo8uJLXYiLCgDcL5LvFf7KFfBul"
                                  />
                                  <button
                                    className="btn btn-sm btn-icon btn-danger me-2"
                                    data-toggle="tooltip"
                                    data-placement="top"
                                    title=""
                                    data-original-title="Delete"
                                  >
                                    {" "}
                                    <FontAwesomeIcon
                                      icon={faTrashAlt}
                                      style={{ color: "white" }}
                                    />
                                  </button>
                                </form>
                              </td>
                            </tr>
                            <tr>
                              <td>9</td>
                              <td>Colleen Hurst</td>
                              <td>Javascript Developer</td>
                              <td>San Francisco</td>
                              <td>39</td>
                              <td>2009/09/15</td>
                              <td className="d-flex">
                                <a
                                  href=""
                                  className="btn btn-sm btn-icon me-2  float-left btn-info"
                                  data-toggle="tooltip"
                                  data-placement="top"
                                  title=""
                                  data-original-title="View"
                                >
                                  {" "}
                                  <FontAwesomeIcon
                                    icon={faEye}
                                    style={{ color: "white" }}
                                  />
                                </a>
                                <a
                                  href=""
                                  className="btn btn-sm btn-icon float-left btn-primary me-2"
                                  data-toggle="tooltip"
                                  data-placement="top"
                                  title=""
                                  data-original-title="Edit"
                                >
                                  {" "}
                                  <FontAwesomeIcon
                                    icon={faPencilSquare}
                                    style={{ color: "white" }}
                                  />
                                </a>
                                <form
                                  className="float-left pl-2"
                                  action="https://fit-buddy.io/admin/admin/menu-items/1615"
                                  method="POST"
                                >
                                  <input
                                    type="hidden"
                                    name="_method"
                                    value="DELETE"
                                  />
                                  <input
                                    type="hidden"
                                    name="_token"
                                    value="C4KWMkgrCT3CJNo8uJLXYiLCgDcL5LvFf7KFfBul"
                                  />
                                  <button
                                    className="btn btn-sm btn-icon btn-danger me-2"
                                    data-toggle="tooltip"
                                    data-placement="top"
                                    title=""
                                    data-original-title="Delete"
                                  >
                                    {" "}
                                    <FontAwesomeIcon
                                      icon={faTrashAlt}
                                      style={{ color: "white" }}
                                    />
                                  </button>
                                </form>
                              </td>
                            </tr>
                            <tr>
                              <td>10</td>
                              <td>Sonya Frost</td>
                              <td>Software Engineer</td>
                              <td>Edinburgh</td>
                              <td>23</td>
                              <td>2008/12/13</td>
                              <td className="d-flex">
                                <a
                                  href=""
                                  className="btn btn-sm btn-icon me-2  float-left btn-info"
                                  data-toggle="tooltip"
                                  data-placement="top"
                                  title=""
                                  data-original-title="View"
                                >
                                  {" "}
                                  <FontAwesomeIcon
                                    icon={faEye}
                                    style={{ color: "white" }}
                                  />
                                </a>
                                <a
                                  href=""
                                  className="btn btn-sm btn-icon float-left btn-primary me-2"
                                  data-toggle="tooltip"
                                  data-placement="top"
                                  title=""
                                  data-original-title="Edit"
                                >
                                  {" "}
                                  <FontAwesomeIcon
                                    icon={faPencilSquare}
                                    style={{ color: "white" }}
                                  />
                                </a>
                                <form
                                  className="float-left pl-2"
                                  action="https://fit-buddy.io/admin/admin/menu-items/1615"
                                  method="POST"
                                >
                                  <input
                                    type="hidden"
                                    name="_method"
                                    value="DELETE"
                                  />
                                  <input
                                    type="hidden"
                                    name="_token"
                                    value="C4KWMkgrCT3CJNo8uJLXYiLCgDcL5LvFf7KFfBul"
                                  />
                                  <button
                                    className="btn btn-sm btn-icon btn-danger me-2"
                                    data-toggle="tooltip"
                                    data-placement="top"
                                    title=""
                                    data-original-title="Delete"
                                  >
                                    {" "}
                                    <FontAwesomeIcon
                                      icon={faTrashAlt}
                                      style={{ color: "white" }}
                                    />
                                  </button>
                                </form>
                              </td>
                            </tr>
                            <tr>
                              <td>11</td>
                              <td>Jena Gaines</td>
                              <td>Office Manager</td>
                              <td>London</td>
                              <td>30</td>
                              <td>2008/12/19</td>
                              <td className="d-flex">
                                <a
                                  href=""
                                  className="btn btn-sm btn-icon me-2  float-left btn-info"
                                  data-toggle="tooltip"
                                  data-placement="top"
                                  title=""
                                  data-original-title="View"
                                >
                                  {" "}
                                  <FontAwesomeIcon
                                    icon={faEye}
                                    style={{ color: "white" }}
                                  />
                                </a>
                                <a
                                  href=""
                                  className="btn btn-sm btn-icon float-left btn-primary me-2"
                                  data-toggle="tooltip"
                                  data-placement="top"
                                  title=""
                                  data-original-title="Edit"
                                >
                                  {" "}
                                  <FontAwesomeIcon
                                    icon={faPencilSquare}
                                    style={{ color: "white" }}
                                  />
                                </a>
                                <form
                                  className="float-left pl-2"
                                  action="https://fit-buddy.io/admin/admin/menu-items/1615"
                                  method="POST"
                                >
                                  <input
                                    type="hidden"
                                    name="_method"
                                    value="DELETE"
                                  />
                                  <input
                                    type="hidden"
                                    name="_token"
                                    value="C4KWMkgrCT3CJNo8uJLXYiLCgDcL5LvFf7KFfBul"
                                  />
                                  <button
                                    className="btn btn-sm btn-icon btn-danger me-2"
                                    data-toggle="tooltip"
                                    data-placement="top"
                                    title=""
                                    data-original-title="Delete"
                                  >
                                    {" "}
                                    <FontAwesomeIcon
                                      icon={faTrashAlt}
                                      style={{ color: "white" }}
                                    />
                                  </button>
                                </form>
                              </td>
                            </tr>
                            <tr>
                              <td>12</td>
                              <td>Angelica Ramos</td>
                              <td>Chief Executive Officer (CEO)</td>
                              <td>London</td>
                              <td>47</td>
                              <td>2009/10/09</td>
                              <td className="d-flex">
                                <a
                                  href=""
                                  className="btn btn-sm btn-icon me-2  float-left btn-info"
                                  data-toggle="tooltip"
                                  data-placement="top"
                                  title=""
                                  data-original-title="View"
                                >
                                  {" "}
                                  <FontAwesomeIcon
                                    icon={faEye}
                                    style={{ color: "white" }}
                                  />
                                </a>
                                <a
                                  href=""
                                  className="btn btn-sm btn-icon float-left btn-primary me-2"
                                  data-toggle="tooltip"
                                  data-placement="top"
                                  title=""
                                  data-original-title="Edit"
                                >
                                  {" "}
                                  <FontAwesomeIcon
                                    icon={faPencilSquare}
                                    style={{ color: "white" }}
                                  />
                                </a>
                                <form
                                  className="float-left pl-2"
                                  action="https://fit-buddy.io/admin/admin/menu-items/1615"
                                  method="POST"
                                >
                                  <input
                                    type="hidden"
                                    name="_method"
                                    value="DELETE"
                                  />
                                  <input
                                    type="hidden"
                                    name="_token"
                                    value="C4KWMkgrCT3CJNo8uJLXYiLCgDcL5LvFf7KFfBul"
                                  />
                                  <button
                                    className="btn btn-sm btn-icon btn-danger me-2"
                                    data-toggle="tooltip"
                                    data-placement="top"
                                    title=""
                                    data-original-title="Delete"
                                  >
                                    {" "}
                                    <FontAwesomeIcon
                                      icon={faTrashAlt}
                                      style={{ color: "white" }}
                                    />
                                  </button>
                                </form>
                              </td>
                            </tr>
                            <tr>
                              <td>13</td>
                              <td>Gavin Joyce</td>
                              <td>Developer</td>
                              <td>Edinburgh</td>
                              <td>42</td>
                              <td>2010/12/22</td>
                              <td className="d-flex">
                                <a
                                  href=""
                                  className="btn btn-sm btn-icon me-2  float-left btn-info"
                                  data-toggle="tooltip"
                                  data-placement="top"
                                  title=""
                                  data-original-title="View"
                                >
                                  {" "}
                                  <FontAwesomeIcon
                                    icon={faEye}
                                    style={{ color: "white" }}
                                  />
                                </a>
                                <a
                                  href=""
                                  className="btn btn-sm btn-icon float-left btn-primary me-2"
                                  data-toggle="tooltip"
                                  data-placement="top"
                                  title=""
                                  data-original-title="Edit"
                                >
                                  {" "}
                                  <FontAwesomeIcon
                                    icon={faPencilSquare}
                                    style={{ color: "white" }}
                                  />
                                </a>
                                <form
                                  className="float-left pl-2"
                                  action="https://fit-buddy.io/admin/admin/menu-items/1615"
                                  method="POST"
                                >
                                  <input
                                    type="hidden"
                                    name="_method"
                                    value="DELETE"
                                  />
                                  <input
                                    type="hidden"
                                    name="_token"
                                    value="C4KWMkgrCT3CJNo8uJLXYiLCgDcL5LvFf7KFfBul"
                                  />
                                  <button
                                    className="btn btn-sm btn-icon btn-danger me-2"
                                    data-toggle="tooltip"
                                    data-placement="top"
                                    title=""
                                    data-original-title="Delete"
                                  >
                                    {" "}
                                    <FontAwesomeIcon
                                      icon={faTrashAlt}
                                      style={{ color: "white" }}
                                    />
                                  </button>
                                </form>
                              </td>
                            </tr>
                            <tr>
                              <td>14</td>
                              <td>Brenden Wagner</td>
                              <td>Software Engineer</td>
                              <td>San Francisco</td>
                              <td>28</td>
                              <td>2011/06/07</td>
                              <td className="d-flex">
                                <a
                                  href=""
                                  className="btn btn-sm btn-icon me-2  float-left btn-info"
                                  data-toggle="tooltip"
                                  data-placement="top"
                                  title=""
                                  data-original-title="View"
                                >
                                  {" "}
                                  <FontAwesomeIcon
                                    icon={faEye}
                                    style={{ color: "white" }}
                                  />
                                </a>
                                <a
                                  href=""
                                  className="btn btn-sm btn-icon float-left btn-primary me-2"
                                  data-toggle="tooltip"
                                  data-placement="top"
                                  title=""
                                  data-original-title="Edit"
                                >
                                  {" "}
                                  <FontAwesomeIcon
                                    icon={faPencilSquare}
                                    style={{ color: "white" }}
                                  />
                                </a>
                                <form
                                  className="float-left pl-2"
                                  action="https://fit-buddy.io/admin/admin/menu-items/1615"
                                  method="POST"
                                >
                                  <input
                                    type="hidden"
                                    name="_method"
                                    value="DELETE"
                                  />
                                  <input
                                    type="hidden"
                                    name="_token"
                                    value="C4KWMkgrCT3CJNo8uJLXYiLCgDcL5LvFf7KFfBul"
                                  />
                                  <button
                                    className="btn btn-sm btn-icon btn-danger me-2"
                                    data-toggle="tooltip"
                                    data-placement="top"
                                    title=""
                                    data-original-title="Delete"
                                  >
                                    {" "}
                                    <FontAwesomeIcon
                                      icon={faTrashAlt}
                                      style={{ color: "white" }}
                                    />
                                  </button>
                                </form>
                              </td>
                            </tr>
                            <tr>
                              <td>15</td>
                              <td>Fiona Green</td>
                              <td>Chief Operating Officer (COO)</td>
                              <td>San Francisco</td>
                              <td>48</td>
                              <td>2010/03/11</td>
                              <td className="d-flex">
                                <a
                                  href=""
                                  className="btn btn-sm btn-icon me-2  float-left btn-info"
                                  data-toggle="tooltip"
                                  data-placement="top"
                                  title=""
                                  data-original-title="View"
                                >
                                  {" "}
                                  <FontAwesomeIcon
                                    icon={faEye}
                                    style={{ color: "white" }}
                                  />
                                </a>
                                <a
                                  href=""
                                  className="btn btn-sm btn-icon float-left btn-primary me-2"
                                  data-toggle="tooltip"
                                  data-placement="top"
                                  title=""
                                  data-original-title="Edit"
                                >
                                  {" "}
                                  <FontAwesomeIcon
                                    icon={faPencilSquare}
                                    style={{ color: "white" }}
                                  />
                                </a>
                                <form
                                  className="float-left pl-2"
                                  action="https://fit-buddy.io/admin/admin/menu-items/1615"
                                  method="POST"
                                >
                                  <input
                                    type="hidden"
                                    name="_method"
                                    value="DELETE"
                                  />
                                  <input
                                    type="hidden"
                                    name="_token"
                                    value="C4KWMkgrCT3CJNo8uJLXYiLCgDcL5LvFf7KFfBul"
                                  />
                                  <button
                                    className="btn btn-sm btn-icon btn-danger me-2"
                                    data-toggle="tooltip"
                                    data-placement="top"
                                    title=""
                                    data-original-title="Delete"
                                  >
                                    {" "}
                                    <FontAwesomeIcon
                                      icon={faTrashAlt}
                                      style={{ color: "white" }}
                                    />
                                  </button>
                                </form>
                              </td>
                            </tr>
                            <tr>
                              <td>16</td>
                              <td>Bruno Nash</td>
                              <td>Software Engineer</td>
                              <td>London</td>
                              <td>38</td>
                              <td>2011/05/03</td>
                              <td className="d-flex">
                                <a
                                  href=""
                                  className="btn btn-sm btn-icon me-2  float-left btn-info"
                                  data-toggle="tooltip"
                                  data-placement="top"
                                  title=""
                                  data-original-title="View"
                                >
                                  {" "}
                                  <FontAwesomeIcon
                                    icon={faEye}
                                    style={{ color: "white" }}
                                  />
                                </a>
                                <a
                                  href=""
                                  className="btn btn-sm btn-icon float-left btn-primary me-2"
                                  data-toggle="tooltip"
                                  data-placement="top"
                                  title=""
                                  data-original-title="Edit"
                                >
                                  {" "}
                                  <FontAwesomeIcon
                                    icon={faPencilSquare}
                                    style={{ color: "white" }}
                                  />
                                </a>
                                <form
                                  className="float-left pl-2"
                                  action="https://fit-buddy.io/admin/admin/menu-items/1615"
                                  method="POST"
                                >
                                  <input
                                    type="hidden"
                                    name="_method"
                                    value="DELETE"
                                  />
                                  <input
                                    type="hidden"
                                    name="_token"
                                    value="C4KWMkgrCT3CJNo8uJLXYiLCgDcL5LvFf7KFfBul"
                                  />
                                  <button
                                    className="btn btn-sm btn-icon btn-danger me-2"
                                    data-toggle="tooltip"
                                    data-placement="top"
                                    title=""
                                    data-original-title="Delete"
                                  >
                                    {" "}
                                    <FontAwesomeIcon
                                      icon={faTrashAlt}
                                      style={{ color: "white" }}
                                    />
                                  </button>
                                </form>
                              </td>
                            </tr>
                            <tr>
                              <td>17</td>
                              <td>Finn Camacho</td>
                              <td>Support Engineer</td>
                              <td>San Francisco</td>
                              <td>47</td>
                              <td>2009/07/07</td>
                              <td className="d-flex">
                                <a
                                  href=""
                                  className="btn btn-sm btn-icon me-2  float-left btn-info"
                                  data-toggle="tooltip"
                                  data-placement="top"
                                  title=""
                                  data-original-title="View"
                                >
                                  {" "}
                                  <FontAwesomeIcon
                                    icon={faEye}
                                    style={{ color: "white" }}
                                  />
                                </a>
                                <a
                                  href=""
                                  className="btn btn-sm btn-icon float-left btn-primary me-2"
                                  data-toggle="tooltip"
                                  data-placement="top"
                                  title=""
                                  data-original-title="Edit"
                                >
                                  {" "}
                                  <FontAwesomeIcon
                                    icon={faPencilSquare}
                                    style={{ color: "white" }}
                                  />
                                </a>
                                <form
                                  className="float-left pl-2"
                                  action="https://fit-buddy.io/admin/admin/menu-items/1615"
                                  method="POST"
                                >
                                  <input
                                    type="hidden"
                                    name="_method"
                                    value="DELETE"
                                  />
                                  <input
                                    type="hidden"
                                    name="_token"
                                    value="C4KWMkgrCT3CJNo8uJLXYiLCgDcL5LvFf7KFfBul"
                                  />
                                  <button
                                    className="btn btn-sm btn-icon btn-danger me-2"
                                    data-toggle="tooltip"
                                    data-placement="top"
                                    title=""
                                    data-original-title="Delete"
                                  >
                                    {" "}
                                    <FontAwesomeIcon
                                      icon={faTrashAlt}
                                      style={{ color: "white" }}
                                    />
                                  </button>
                                </form>
                              </td>
                            </tr>

                            <tr>
                              <td>18</td>
                              <td>Cara Stevens</td>
                              <td>Sales Assistant</td>
                              <td>New York</td>
                              <td>46</td>
                              <td>2011/12/06</td>
                              <td className="d-flex">
                                <a
                                  href=""
                                  className="btn btn-sm btn-icon me-2  float-left btn-info"
                                  data-toggle="tooltip"
                                  data-placement="top"
                                  title=""
                                  data-original-title="View"
                                >
                                  {" "}
                                  <FontAwesomeIcon
                                    icon={faEye}
                                    style={{ color: "white" }}
                                  />
                                </a>
                                <a
                                  href=""
                                  className="btn btn-sm btn-icon float-left btn-primary me-2"
                                  data-toggle="tooltip"
                                  data-placement="top"
                                  title=""
                                  data-original-title="Edit"
                                >
                                  {" "}
                                  <FontAwesomeIcon
                                    icon={faPencilSquare}
                                    style={{ color: "white" }}
                                  />
                                </a>
                                <form
                                  className="float-left pl-2"
                                  action="https://fit-buddy.io/admin/admin/menu-items/1615"
                                  method="POST"
                                >
                                  <input
                                    type="hidden"
                                    name="_method"
                                    value="DELETE"
                                  />
                                  <input
                                    type="hidden"
                                    name="_token"
                                    value="C4KWMkgrCT3CJNo8uJLXYiLCgDcL5LvFf7KFfBul"
                                  />
                                  <button
                                    className="btn btn-sm btn-icon btn-danger me-2"
                                    data-toggle="tooltip"
                                    data-placement="top"
                                    title=""
                                    data-original-title="Delete"
                                  >
                                    {" "}
                                    <FontAwesomeIcon
                                      icon={faTrashAlt}
                                      style={{ color: "white" }}
                                    />
                                  </button>
                                </form>
                              </td>
                            </tr>
                            <tr>
                              <td>20</td>
                              <td>Michael Bruce</td>
                              <td>Javascript Developer</td>
                              <td>Singapore</td>
                              <td>29</td>
                              <td>2011/06/27</td>
                              <td className="d-flex">
                                <a
                                  href=""
                                  className="btn btn-sm btn-icon me-2  float-left btn-info"
                                  data-toggle="tooltip"
                                  data-placement="top"
                                  title=""
                                  data-original-title="View"
                                >
                                  {" "}
                                  <FontAwesomeIcon
                                    icon={faEye}
                                    style={{ color: "white" }}
                                  />
                                </a>
                                <a
                                  href=""
                                  className="btn btn-sm btn-icon float-left btn-primary me-2"
                                  data-toggle="tooltip"
                                  data-placement="top"
                                  title=""
                                  data-original-title="Edit"
                                >
                                  {" "}
                                  <FontAwesomeIcon
                                    icon={faPencilSquare}
                                    style={{ color: "white" }}
                                  />
                                </a>
                                <form
                                  className="float-left pl-2"
                                  action="https://fit-buddy.io/admin/admin/menu-items/1615"
                                  method="POST"
                                >
                                  <input
                                    type="hidden"
                                    name="_method"
                                    value="DELETE"
                                  />
                                  <input
                                    type="hidden"
                                    name="_token"
                                    value="C4KWMkgrCT3CJNo8uJLXYiLCgDcL5LvFf7KFfBul"
                                  />
                                  <button
                                    className="btn btn-sm btn-icon btn-danger me-2"
                                    data-toggle="tooltip"
                                    data-placement="top"
                                    title=""
                                    data-original-title="Delete"
                                  >
                                    {" "}
                                    <FontAwesomeIcon
                                      icon={faTrashAlt}
                                      style={{ color: "white" }}
                                    />
                                  </button>
                                </form>
                              </td>
                            </tr>
                            <tr>
                              <td>21</td>
                              <td>Donna Snider</td>
                              <td>Customer Support</td>
                              <td>New York</td>
                              <td>27</td>
                              <td>2011/01/25</td>
                              <td className="d-flex">
                                <a
                                  href=""
                                  className="btn btn-sm btn-icon me-2  float-left btn-info"
                                  data-toggle="tooltip"
                                  data-placement="top"
                                  title=""
                                  data-original-title="View"
                                >
                                  {" "}
                                  <FontAwesomeIcon
                                    icon={faEye}
                                    style={{ color: "white" }}
                                  />
                                </a>
                                <a
                                  href=""
                                  className="btn btn-sm btn-icon float-left btn-primary me-2"
                                  data-toggle="tooltip"
                                  data-placement="top"
                                  title=""
                                  data-original-title="Edit"
                                >
                                  {" "}
                                  <FontAwesomeIcon
                                    icon={faPencilSquare}
                                    style={{ color: "white" }}
                                  />
                                </a>
                                <form
                                  className="float-left pl-2"
                                  action="https://fit-buddy.io/admin/admin/menu-items/1615"
                                  method="POST"
                                >
                                  <input
                                    type="hidden"
                                    name="_method"
                                    value="DELETE"
                                  />
                                  <input
                                    type="hidden"
                                    name="_token"
                                    value="C4KWMkgrCT3CJNo8uJLXYiLCgDcL5LvFf7KFfBul"
                                  />
                                  <button
                                    className="btn btn-sm btn-icon btn-danger me-2"
                                    data-toggle="tooltip"
                                    data-placement="top"
                                    title=""
                                    data-original-title="Delete"
                                  >
                                    {" "}
                                    <FontAwesomeIcon
                                      icon={faTrashAlt}
                                      style={{ color: "white" }}
                                    />
                                  </button>
                                </form>
                              </td>
                            </tr>
                          </tbody>
                        </table>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </main>
        {/* <!-- end::main-content --> */}
      </div>
      {/* <!-- end::main --></tr> */}
    </>
  );
}

export default Investors;
