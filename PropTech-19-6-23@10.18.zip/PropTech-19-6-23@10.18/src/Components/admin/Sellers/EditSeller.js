import React from "react";

const EditSeller = () => {
  return (
    <div class="rtl">
      <div id="main">
        {/* <!-- begin::main-content --> */}
        <div class="main-content">
          <div class="container">
            {/* <!-- begin::page-header --> */}
            <div class="page-header">
              <h4>Edit Seller</h4>
              <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                  <li class="breadcrumb-item">
                    <a href="#">Home</a>
                  </li>
                  <li class="breadcrumb-item">
                    <a href="#">User Management</a>
                  </li>
                  <li class="breadcrumb-item">
                    <a href="#">Sellers</a>
                  </li>
                  <li class="breadcrumb-item active" aria-current="page">
                    Edit Seller
                  </li>
                </ol>
              </nav>
            </div>
            {/* <!-- end::page-header --> */}

            <div class="row">
              <div class="col-md-12">
                <div class="card">
                  <div class="card-body">
                    <form class="needs-validation" novalidate="">
                      <div class="form-row">
                        <div class="col-md-4 mb-3">
                          <label for="validationCustom01">Full Name</label>
                          <input
                            type="text"
                            class="form-control"
                            id="validationCustom01"
                            placeholder="enter your full name"
                            required=""
                          />
                          <div class="valid-feedback">Looks good!</div>
                        </div>
                        <div class="col-md-4 mb-3">
                          <label for="validationCustom02">Contact Number</label>
                          <input
                            type="text"
                            data-input-mask="phone"
                            class="form-control"
                            id="validationCustom02"
                            placeholder="9087654321"
                            required=""
                          />
                          <div class="valid-feedback">Looks good!</div>
                        </div>
                        <div class="col-md-4 mb-3">
                          <label for="validationCustom03">Email Address</label>
                          <input
                            type="email"
                            class="form-control"
                            id="validationCustom03"
                            placeholder=""
                            required=""
                          />
                          <div class="valid-feedback">Looks good!</div>
                        </div>
                      </div>
                      <div class="form-row">
                        <div class="col-md-6 mb-3">
                          <label for="validationCustom04">Address</label>
                          <input
                            type="text"
                            class="form-control"
                            id="validationCustom04"
                            placeholder=""
                            required=""
                          />
                          <div class="invalid-feedback">
                            Please provide a valid location.
                          </div>
                        </div>

                        <div class="col-md-6 mb-3">
                          <label for="validationCustom06">
                            Company/Agency Name (if applicable)
                          </label>
                          <input
                            type="text"
                            class="form-control"
                            id="validationCustom06"
                            placeholder=""
                            required=""
                          />
                          <div class="invalid-feedback"></div>
                        </div>
                        <div class="col-md-6 mb-3">
                          <label for="validationCustom05">
                            Verification Status
                          </label>
                          <input
                            type="text"
                            class="form-control"
                            id="validationCustom05"
                            placeholder=""
                            required=""
                          />

                          {/* <!-- <input type="text" class="form-control" id="validationCustom05" placeholder="enter amenities"required=""> --> */}
                          <div class="invalid-feedback"></div>
                        </div>
                      </div>
                      <div class="form-group">
                        <div class="form-check">
                          <input
                            class="form-check-input"
                            type="checkbox"
                            value=""
                            id="invalidCheck"
                            required=""
                          />
                          <label class="form-check-label" for="invalidCheck">
                            Agree to terms and conditions
                          </label>
                          <div class="invalid-feedback">
                            You must agree before submitting.
                          </div>
                        </div>
                      </div>
                      <button class="btn btn-primary" type="submit">
                        Submit{" "}
                      </button>
                    </form>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        {/* <!-- end::main-content --> */}
      </div>
    </div>
  );
};

export default EditSeller;
