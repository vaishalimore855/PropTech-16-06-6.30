import logo from "./logo.svg";
// import './App.css';
// import './App.min.css';
import "./assets/css/custom.css";
import "./assets/css/app.css";
// import './assets/css/app.min.css'
import "./assets/css/RealCustom.css";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Login from "./Components/auth/login";
import Profile from "./Components/admin/Profile";
import Sidebar from "./Components/Sidebar/Sidebar";
import ResetPassword from "./Components/auth/ResetPassword";
import Header from "./Components/admin/Header";
import Footer from "./Components/admin/Footer";
import AddInvestorForm from "./Components/admin/Investor/AddInvestorForm";
import Investors from "./Components/admin/Investor/Investors";
import Sellers from "./Components/admin/Sellers/Sellers";
import AddSellersForm from "./Components/admin/Sellers/AddSellersForm";
import PropertyListing from "./Components/admin/PropertyListing/PropertyListing";
import AddBuyer from "./Components/admin/Buyer/AddBuyer";
import Buyer from "./Components/admin/Buyer/Buyer";
import Home from "./Components/admin/Home/Home";
import EditBuyer from "./Components/admin/Buyer/EditBuyer";
import EditInvestor from "./Components/admin/Investor/EditInvestor";
import EditProperty from "./Components/admin/PropertyListing/EditProperty";
import EditSeller from "./Components/admin/Sellers/EditSeller";
import DocVerification from "./Components/admin/DocumentVerification/DocVerification";
import AddProperty from "./Components/admin/PropertyListing/AddProperty";

function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" exact element={<Login />}></Route>
        <Route path="/header" exact element={<Header />}></Route>
        <Route path="footer" exact element={<Footer />}></Route>
        <Route path="/reset-password" element={<ResetPassword />}></Route>
        <Route path="/profile" element={<Profile />}></Route>
        <Route path="/buyer" element={<Buyer />}></Route>
        <Route path="/add-buyer" element={<AddBuyer />}></Route>
        <Route path="/edit-buyer" element={<EditBuyer />}></Route>
        <Route path="sidebar/" element={<Sidebar />}></Route>
        <Route path="/homepage" element={<Home />}></Route>
        <Route path="/add-investor" element={<AddInvestorForm />}></Route>
        <Route path="/investor" element={<Investors />}></Route>
        <Route path="/edit-investor" element={<EditInvestor />}></Route>
        <Route path="/sellers" element={<Sellers />}></Route>
        <Route path="/edit-sellers" element={<EditSeller />}></Route>
        <Route path="/add-sellers" element={<AddSellersForm />}></Route>
        <Route path="/property-listing" element={<PropertyListing />}></Route>
        <Route path="/edit-property" element={<EditProperty/>}></Route>
        <Route path="/add-property" element={<AddProperty/>}></Route>
        <Route path="/document-verification" element={<DocVerification/>}></Route>
      </Routes>
    </BrowserRouter>
  );
}

export default App;
  