import React from "react";
import { Link, useNavigate } from "react-router-dom";
//icons
import "bootstrap/dist/css/bootstrap.min.css";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faEye } from "@fortawesome/free-solid-svg-icons";
import { faPencilSquare } from "@fortawesome/free-solid-svg-icons";
import { faTrash, faTrashAlt } from "@fortawesome/free-solid-svg-icons";
const PropertyListing = () => {
    var navigate = useNavigate();
    const handleClick = () => {
      navigate("/add-property");
      navigate("/edit-property");
    };
  return (
    <>
      <div id="main">
        {/* <!-- begin::main-content --> */}
        <main class="main-content">
          <div class="container">
            {/* <!-- begin::page-header --> */}
            <div class="page-header mt-5">
              <h4>Property Listing</h4>
              <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                  <li class="breadcrumb-item">
                   <Link href="#">Home</Link>
                  </li>
                  <li class="breadcrumb-item">
                   <Link href="#">Property Listing</Link>
                  </li>
                </ol>
              </nav>
            </div>
            {/* <!-- end::page-header --> */}

            <div class="row">
              <div class="col-md-12">
                <div class="card">
                  <div class="card-body">
                    <div class="pt-4 pb-4 text-left">
                      <button
                        type="button"
                        class="btn btn-primary btn-rounded  "
                      >
                    
                   <Link to="/add-property" className="active  text-white">
                    Add Property
                  </Link>
                      </button>
                    </div>

                    <div class="card">
                      <div class="card-body">
                        <table
                          id="example2"
                          class="table table-striped table-bordered"
                        >
                          <thead>
                            <tr>
                              <th>ID</th>
                              <th>Name Of Property</th>
                              <th>RERA Number</th>
                              <th>Price</th>
                              <th>Location</th>
                              <th>Status</th>
                              <th>Actions</th>
                            </tr>
                          </thead>
                          <tbody>
                            <tr>
                              <td>1</td>
                              <td>Tiger Nixon</td>
                              <td>Agent</td>
                              <td>Edinburgh</td>
                              <td>61</td>
                              <td>
                                <label class="switch">
                                  <input type="checkbox" />
                                  <span class="slider round"></span>
                                </label>
                              </td>
                              <td class="d-flex">
                               <Link
                                  to=""
                                  class="btn btn-sm btn-icon me-2
                                                              float-left btn-info"
                                  data-toggle="tooltip"
                                  data-placement="top"
                                  title=""
                                  data-original-title="View"
                                >
                                  <FontAwesomeIcon
                                    icon={faEye}
                                    style={{ color: "white" }}
                                  />
                               </Link>
                               <Link
                                  to="/edit-property"
                                  class="btn btn-sm btn-icon float-left btn-primary me-2"
                                  data-toggle="tooltip"
                                  data-placement="top"
                                  title=""
                                  data-original-title="Edit"
                                >
                                  {" "}
                                  <FontAwesomeIcon
                                    icon={faPencilSquare}
                                    style={{ color: "white" }}
                                  />
                               </Link>
                                <form
                                  class="float-left pl-2 me-2"
                                  action="https://fit-buddy.io/admin/admin/menu-items/1615"
                                  method="POST"
                                >
                                  <input
                                    type="hidden"
                                    name="_method"
                                    value="DELETE"
                                  />
                                  <input
                                    type="hidden"
                                    name="_token"
                                    value="C4KWMkgrCT3CJNo8uJLXYiLCgDcL5LvFf7KFfBul"
                                  />
                                  <button
                                    class="btn btn-sm btn-icon btn-danger"
                                    data-toggle="tooltip"
                                    data-placement="top"
                                    title=""
                                    data-original-title="Delete"
                                  >
                                    {" "}
                                    <FontAwesomeIcon
                                      icon={faTrashAlt}
                                      style={{ color: "white" }}
                                    />
                                  </button>
                                </form>
                              </td>
                            </tr>
                            <tr>
                              <td>2</td>
                              <td>Garrett Winters</td>
                              <td>Agent</td>
                              <td>Tokyo</td>
                              <td>63</td>
                              <td>
                                <label class="switch">
                                  <input type="checkbox" />
                                  <span class="slider round"></span>
                                </label>
                              </td>
                              <td class="d-flex">
                               <Link
                                  to=""
                                  class="btn btn-sm btn-icon me-2
                                                              float-left btn-info"
                                  data-toggle="tooltip"
                                  data-placement="top"
                                  title=""
                                  data-original-title="View"
                                >
                                  <FontAwesomeIcon
                                    icon={faEye}
                                    style={{ color: "white" }}
                                  />
                               </Link>
                               <Link
                                  to="/edit-property"
                                  class="btn btn-sm btn-icon float-left btn-primary me-2"
                                  data-toggle="tooltip"
                                  data-placement="top"
                                  title=""
                                  data-original-title="Edit"
                                >
                                  {" "}
                                  <FontAwesomeIcon
                                    icon={faPencilSquare}
                                    style={{ color: "white" }}
                                  />
                               </Link>
                                <form
                                  class="float-left pl-2 me-2"
                                  action="https://fit-buddy.io/admin/admin/menu-items/1615"
                                  method="POST"
                                >
                                  <input
                                    type="hidden"
                                    name="_method"
                                    value="DELETE"
                                  />
                                  <input
                                    type="hidden"
                                    name="_token"
                                    value="C4KWMkgrCT3CJNo8uJLXYiLCgDcL5LvFf7KFfBul"
                                  />
                                  <button
                                    class="btn btn-sm btn-icon btn-danger"
                                    data-toggle="tooltip"
                                    data-placement="top"
                                    title=""
                                    data-original-title="Delete"
                                  >
                                    {" "}
                                    <FontAwesomeIcon
                                      icon={faTrashAlt}
                                      style={{ color: "white" }}
                                    />
                                  </button>
                                </form>
                              </td>
                            </tr>
                            <tr>
                              <td>3</td>
                              <td>Ashton Cox</td>
                              <td>Agent</td>
                              <td>San Francisco</td>
                              <td>66</td>
                              <td>
                                <label class="switch">
                                  <input type="checkbox" />
                                  <span class="slider round"></span>
                                </label>
                              </td>
                              <td class="d-flex">
                               <Link
                                  to=""
                                  class="btn btn-sm btn-icon me-2
                                                              float-left btn-info"
                                  data-toggle="tooltip"
                                  data-placement="top"
                                  title=""
                                  data-original-title="View"
                                >
                                  <FontAwesomeIcon
                                    icon={faEye}
                                    style={{ color: "white" }}
                                  />
                               </Link>
                               <Link
                                  to=""
                                  class="btn btn-sm btn-icon float-left btn-primary me-2"
                                  data-toggle="tooltip"
                                  data-placement="top"
                                  title=""
                                  data-original-title="Edit"
                                >
                                  {" "}
                                  <FontAwesomeIcon
                                    icon={faPencilSquare}
                                    style={{ color: "white" }}
                                  />
                               </Link>
                                <form
                                  class="float-left pl-2 me-2"
                                  action="https://fit-buddy.io/admin/admin/menu-items/1615"
                                  method="POST"
                                >
                                  <input
                                    type="hidden"
                                    name="_method"
                                    value="DELETE"
                                  />
                                  <input
                                    type="hidden"
                                    name="_token"
                                    value="C4KWMkgrCT3CJNo8uJLXYiLCgDcL5LvFf7KFfBul"
                                  />
                                  <button
                                    class="btn btn-sm btn-icon btn-danger"
                                    data-toggle="tooltip"
                                    data-placement="top"
                                    title=""
                                    data-original-title="Delete"
                                  >
                                    {" "}
                                    <FontAwesomeIcon
                                      icon={faTrashAlt}
                                      style={{ color: "white" }}
                                    />
                                  </button>
                                </form>
                              </td>
                            </tr>
                            <tr>
                              <td>4</td>
                              <td>Cedric Kelly</td>
                              <td>Agent</td>
                              <td>Edinburgh</td>
                              <td>22</td>
                              <td>
                                <label class="switch">
                                  <input type="checkbox" />
                                  <span class="slider round"></span>
                                </label>
                              </td>
                              <td class="d-flex">
                               <Link
                                  to=""
                                  class="btn btn-sm btn-icon me-2
                                                              float-left btn-info"
                                  data-toggle="tooltip"
                                  data-placement="top"
                                  title=""
                                  data-original-title="View"
                                >
                                  <FontAwesomeIcon
                                    icon={faEye}
                                    style={{ color: "white" }}
                                  />
                               </Link>
                               <Link
                                  to="/edit-property"
                                  class="btn btn-sm btn-icon float-left btn-primary me-2"
                                  data-toggle="tooltip"
                                  data-placement="top"
                                  title=""
                                  data-original-title="Edit"
                                >
                                  {" "}
                                  <FontAwesomeIcon
                                    icon={faPencilSquare}
                                    style={{ color: "white" }}
                                  />
                               </Link>
                                <form
                                  class="float-left pl-2 me-2"
                                  action="https://fit-buddy.io/admin/admin/menu-items/1615"
                                  method="POST"
                                >
                                  <input
                                    type="hidden"
                                    name="_method"
                                    value="DELETE"
                                  />
                                  <input
                                    type="hidden"
                                    name="_token"
                                    value="C4KWMkgrCT3CJNo8uJLXYiLCgDcL5LvFf7KFfBul"
                                  />
                                  <button
                                    class="btn btn-sm btn-icon btn-danger"
                                    data-toggle="tooltip"
                                    data-placement="top"
                                    title=""
                                    data-original-title="Delete"
                                  >
                                    {" "}
                                    <FontAwesomeIcon
                                      icon={faTrashAlt}
                                      style={{ color: "white" }}
                                    />
                                  </button>
                                </form>
                              </td>
                            </tr>
                            <tr>
                              <td>5</td>
                              <td>Airi Satou</td>
                              <td>Agent</td>
                              <td>Tokyo</td>
                              <td>33</td>
                              <td>
                                <label class="switch">
                                  <input type="checkbox" />
                                  <span class="slider round"></span>
                                </label>
                              </td>
                              <td class="d-flex">
                               <Link
                                  to=""
                                  class="btn btn-sm btn-icon me-2
                                                              float-left btn-info"
                                  data-toggle="tooltip"
                                  data-placement="top"
                                  title=""
                                  data-original-title="View"
                                >
                                  <FontAwesomeIcon
                                    icon={faEye}
                                    style={{ color: "white" }}
                                  />
                               </Link>
                               <Link
                                  to=""
                                  class="btn btn-sm btn-icon float-left btn-primary me-2"
                                  data-toggle="tooltip"
                                  data-placement="top"
                                  title=""
                                  data-original-title="Edit"
                                >
                                  {" "}
                                  <FontAwesomeIcon
                                    icon={faPencilSquare}
                                    style={{ color: "white" }}
                                  />
                               </Link>
                                <form
                                  class="float-left pl-2 me-2"
                                  action="https://fit-buddy.io/admin/admin/menu-items/1615"
                                  method="POST"
                                >
                                  <input
                                    type="hidden"
                                    name="_method"
                                    value="DELETE"
                                  />
                                  <input
                                    type="hidden"
                                    name="_token"
                                    value="C4KWMkgrCT3CJNo8uJLXYiLCgDcL5LvFf7KFfBul"
                                  />
                                  <button
                                    class="btn btn-sm btn-icon btn-danger"
                                    data-toggle="tooltip"
                                    data-placement="top"
                                    title=""
                                    data-original-title="Delete"
                                  >
                                    {" "}
                                    <FontAwesomeIcon
                                      icon={faTrashAlt}
                                      style={{ color: "white" }}
                                    />
                                  </button>
                                </form>
                              </td>
                            </tr>
                            <tr>
                              <td>6</td>
                              <td>Brielle Williamson</td>
                              <td>Agent</td>
                              <td>New York</td>
                              <td>61</td>
                              <td>
                                <label class="switch">
                                  <input type="checkbox" />
                                  <span class="slider round"></span>
                                </label>
                              </td>
                              <td class="d-flex">
                               <Link
                                  to=""
                                  class="btn btn-sm btn-icon me-2
                                                              float-left btn-info"
                                  data-toggle="tooltip"
                                  data-placement="top"
                                  title=""
                                  data-original-title="View"
                                >
                                  <FontAwesomeIcon
                                    icon={faEye}
                                    style={{ color: "white" }}
                                  />
                               </Link>
                               <Link
                                  to=""
                                  class="btn btn-sm btn-icon float-left btn-primary me-2"
                                  data-toggle="tooltip"
                                  data-placement="top"
                                  title=""
                                  data-original-title="Edit"
                                >
                                  {" "}
                                  <FontAwesomeIcon
                                    icon={faPencilSquare}
                                    style={{ color: "white" }}
                                  />
                               </Link>
                                <form
                                  class="float-left pl-2 me-2"
                                  action="https://fit-buddy.io/admin/admin/menu-items/1615"
                                  method="POST"
                                >
                                  <input
                                    type="hidden"
                                    name="_method"
                                    value="DELETE"
                                  />
                                  <input
                                    type="hidden"
                                    name="_token"
                                    value="C4KWMkgrCT3CJNo8uJLXYiLCgDcL5LvFf7KFfBul"
                                  />
                                  <button
                                    class="btn btn-sm btn-icon btn-danger"
                                    data-toggle="tooltip"
                                    data-placement="top"
                                    title=""
                                    data-original-title="Delete"
                                  >
                                    {" "}
                                    <FontAwesomeIcon
                                      icon={faTrashAlt}
                                      style={{ color: "white" }}
                                    />
                                  </button>
                                </form>
                              </td>
                            </tr>
                            <tr>
                              <td>7</td>
                              <td>Herrod Chandler</td>
                              <td>Agent</td>
                              <td>San Francisco</td>
                              <td>59</td>
                              <td>
                                <label class="switch">
                                  <input type="checkbox" />
                                  <span class="slider round"></span>
                                </label>
                              </td>
                              <td class="d-flex">
                               <Link
                                  to=""
                                  class="btn btn-sm btn-icon me-2
                                                              float-left btn-info"
                                  data-toggle="tooltip"
                                  data-placement="top"
                                  title=""
                                  data-original-title="View"
                                >
                                  <FontAwesomeIcon
                                    icon={faEye}
                                    style={{ color: "white" }}
                                  />
                               </Link>
                               <Link
                                  to=""
                                  class="btn btn-sm btn-icon float-left btn-primary me-2"
                                  data-toggle="tooltip"
                                  data-placement="top"
                                  title=""
                                  data-original-title="Edit"
                                >
                                  {" "}
                                  <FontAwesomeIcon
                                    icon={faPencilSquare}
                                    style={{ color: "white" }}
                                  />
                               </Link>
                                <form
                                  class="float-left pl-2 me-2"
                                  action="https://fit-buddy.io/admin/admin/menu-items/1615"
                                  method="POST"
                                >
                                  <input
                                    type="hidden"
                                    name="_method"
                                    value="DELETE"
                                  />
                                  <input
                                    type="hidden"
                                    name="_token"
                                    value="C4KWMkgrCT3CJNo8uJLXYiLCgDcL5LvFf7KFfBul"
                                  />
                                  <button
                                    class="btn btn-sm btn-icon btn-danger"
                                    data-toggle="tooltip"
                                    data-placement="top"
                                    title=""
                                    data-original-title="Delete"
                                  >
                                    {" "}
                                    <FontAwesomeIcon
                                      icon={faTrashAlt}
                                      style={{ color: "white" }}
                                    />
                                  </button>
                                </form>
                              </td>
                            </tr>
                            <tr>
                              <td>8</td>
                              <td>Rhona Davidson</td>
                              <td>Agent</td>
                              <td>Tokyo</td>
                              <td>55</td>
                              <td>
                                <label class="switch">
                                  <input type="checkbox" />
                                  <span class="slider round"></span>
                                </label>
                              </td>
                              <td class="d-flex">
                               <Link
                                  to=""
                                  class="btn btn-sm btn-icon me-2
                                                              float-left btn-info"
                                  data-toggle="tooltip"
                                  data-placement="top"
                                  title=""
                                  data-original-title="View"
                                >
                                  <FontAwesomeIcon
                                    icon={faEye}
                                    style={{ color: "white" }}
                                  />
                               </Link>
                               <Link
                                  to=""
                                  class="btn btn-sm btn-icon float-left btn-primary me-2"
                                  data-toggle="tooltip"
                                  data-placement="top"
                                  title=""
                                  data-original-title="Edit"
                                >
                                  {" "}
                                  <FontAwesomeIcon
                                    icon={faPencilSquare}
                                    style={{ color: "white" }}
                                  />
                               </Link>
                                <form
                                  class="float-left pl-2 me-2"
                                  action="https://fit-buddy.io/admin/admin/menu-items/1615"
                                  method="POST"
                                >
                                  <input
                                    type="hidden"
                                    name="_method"
                                    value="DELETE"
                                  />
                                  <input
                                    type="hidden"
                                    name="_token"
                                    value="C4KWMkgrCT3CJNo8uJLXYiLCgDcL5LvFf7KFfBul"
                                  />
                                  <button
                                    class="btn btn-sm btn-icon btn-danger"
                                    data-toggle="tooltip"
                                    data-placement="top"
                                    title=""
                                    data-original-title="Delete"
                                  >
                                    {" "}
                                    <FontAwesomeIcon
                                      icon={faTrashAlt}
                                      style={{ color: "white" }}
                                    />
                                  </button>
                                </form>
                              </td>
                            </tr>
                            <tr>
                              <td>9</td>
                              <td>Colleen Hurst</td>
                              <td>Agent</td>
                              <td>San Francisco</td>
                              <td>39</td>
                              <td>
                                <label class="switch">
                                  <input type="checkbox" />
                                  <span class="slider round"></span>
                                </label>
                              </td>
                              <td class="d-flex">
                               <Link
                                  to=""
                                  class="btn btn-sm btn-icon me-2
                                                              float-left btn-info"
                                  data-toggle="tooltip"
                                  data-placement="top"
                                  title=""
                                  data-original-title="View"
                                >
                                  <FontAwesomeIcon
                                    icon={faEye}
                                    style={{ color: "white" }}
                                  />
                               </Link>
                               <Link
                                  to=""
                                  class="btn btn-sm btn-icon float-left btn-primary me-2"
                                  data-toggle="tooltip"
                                  data-placement="top"
                                  title=""
                                  data-original-title="Edit"
                                >
                                  {" "}
                                  <FontAwesomeIcon
                                    icon={faPencilSquare}
                                    style={{ color: "white" }}
                                  />
                               </Link>
                                <form
                                  class="float-left pl-2 me-2"
                                  action="https://fit-buddy.io/admin/admin/menu-items/1615"
                                  method="POST"
                                >
                                  <input
                                    type="hidden"
                                    name="_method"
                                    value="DELETE"
                                  />
                                  <input
                                    type="hidden"
                                    name="_token"
                                    value="C4KWMkgrCT3CJNo8uJLXYiLCgDcL5LvFf7KFfBul"
                                  />
                                  <button
                                    class="btn btn-sm btn-icon btn-danger"
                                    data-toggle="tooltip"
                                    data-placement="top"
                                    title=""
                                    data-original-title="Delete"
                                  >
                                    {" "}
                                    <FontAwesomeIcon
                                      icon={faTrashAlt}
                                      style={{ color: "white" }}
                                    />
                                  </button>
                                </form>
                              </td>
                            </tr>
                            <tr>
                              <td>10</td>
                              <td>Sonya Frost</td>
                              <td>Agent</td>
                              <td>Edinburgh</td>
                              <td>23</td>
                              <td>
                                <label class="switch">
                                  <input type="checkbox" />
                                  <span class="slider round"></span>
                                </label>
                              </td>
                              <td class="d-flex">
                               <Link
                                  to=""
                                  class="btn btn-sm btn-icon me-2
                                                              float-left btn-info"
                                  data-toggle="tooltip"
                                  data-placement="top"
                                  title=""
                                  data-original-title="View"
                                >
                                  <FontAwesomeIcon
                                    icon={faEye}
                                    style={{ color: "white" }}
                                  />
                               </Link>
                               <Link
                                  to=""
                                  class="btn btn-sm btn-icon float-left btn-primary me-2"
                                  data-toggle="tooltip"
                                  data-placement="top"
                                  title=""
                                  data-original-title="Edit"
                                >
                                  {" "}
                                  <FontAwesomeIcon
                                    icon={faPencilSquare}
                                    style={{ color: "white" }}
                                  />
                               </Link>
                                <form
                                  class="float-left pl-2 me-2"
                                  action="https://fit-buddy.io/admin/admin/menu-items/1615"
                                  method="POST"
                                >
                                  <input
                                    type="hidden"
                                    name="_method"
                                    value="DELETE"
                                  />
                                  <input
                                    type="hidden"
                                    name="_token"
                                    value="C4KWMkgrCT3CJNo8uJLXYiLCgDcL5LvFf7KFfBul"
                                  />
                                  <button
                                    class="btn btn-sm btn-icon btn-danger"
                                    data-toggle="tooltip"
                                    data-placement="top"
                                    title=""
                                    data-original-title="Delete"
                                  >
                                    {" "}
                                    <FontAwesomeIcon
                                      icon={faTrashAlt}
                                      style={{ color: "white" }}
                                    />
                                  </button>
                                </form>
                              </td>
                            </tr>
                            <tr>
                              <td>11</td>
                              <td>Jena Gaines</td>
                              <td>Agent</td>
                              <td>London</td>
                              <td>30</td>
                              <td>
                                <label class="switch">
                                  <input type="checkbox" />
                                  <span class="slider round"></span>
                                </label>
                              </td>
                              <td class="d-flex">
                               <Link
                                  to=""
                                  class="btn btn-sm btn-icon me-2
                                                              float-left btn-info"
                                  data-toggle="tooltip"
                                  data-placement="top"
                                  title=""
                                  data-original-title="View"
                                >
                                  <FontAwesomeIcon
                                    icon={faEye}
                                    style={{ color: "white" }}
                                  />
                               </Link>
                               <Link
                                  to=""
                                  class="btn btn-sm btn-icon float-left btn-primary me-2"
                                  data-toggle="tooltip"
                                  data-placement="top"
                                  title=""
                                  data-original-title="Edit"
                                >
                                  {" "}
                                  <FontAwesomeIcon
                                    icon={faPencilSquare}
                                    style={{ color: "white" }}
                                  />
                               </Link>
                                <form
                                  class="float-left pl-2 me-2"
                                  action="https://fit-buddy.io/admin/admin/menu-items/1615"
                                  method="POST"
                                >
                                  <input
                                    type="hidden"
                                    name="_method"
                                    value="DELETE"
                                  />
                                  <input
                                    type="hidden"
                                    name="_token"
                                    value="C4KWMkgrCT3CJNo8uJLXYiLCgDcL5LvFf7KFfBul"
                                  />
                                  <button
                                    class="btn btn-sm btn-icon btn-danger"
                                    data-toggle="tooltip"
                                    data-placement="top"
                                    title=""
                                    data-original-title="Delete"
                                  >
                                    {" "}
                                    <FontAwesomeIcon
                                      icon={faTrashAlt}
                                      style={{ color: "white" }}
                                    />
                                  </button>
                                </form>
                              </td>
                            </tr>
                            <tr>
                              <td>12</td>
                              <td>Quinn Flynn</td>
                              <td>Seller</td>
                              <td>Edinburgh</td>
                              <td>22</td>
                              <td>2013/03/03</td>
                              <td>$342,000</td>
                            </tr>
                            <tr>
                              <td>13</td>
                              <td>Charde Marshall</td>
                              <td>Seller</td>
                              <td>San Francisco</td>
                              <td>36</td>
                              <td>2008/10/16</td>
                              <td>$470,600</td>
                            </tr>
                            <tr>
                              <td>14</td>
                              <td>Haley Kennedy</td>
                              <td>Seller</td>
                              <td>London</td>
                              <td>43</td>
                              <td>2012/12/18</td>
                              <td>$313,500</td>
                            </tr>

                            <tr>
                              <td>15</td>
                              <td>Angelica Ramos</td>
                              <td>Seller</td>
                              <td>London</td>
                              <td>47</td>
                              <td>2009/10/09</td>
                              <td class="d-flex">
                               <Link
                                  to=""
                                  class="btn btn-sm btn-icon me-2
                                                              float-left btn-info"
                                  data-toggle="tooltip"
                                  data-placement="top"
                                  title=""
                                  data-original-title="View"
                                >
                                  <FontAwesomeIcon
                                    icon={faEye}
                                    style={{ color: "white" }}
                                  />
                               </Link>
                               <Link
                                  to=""
                                  class="btn btn-sm btn-icon float-left btn-primary me-2"
                                  data-toggle="tooltip"
                                  data-placement="top"
                                  title=""
                                  data-original-title="Edit"
                                >
                                  {" "}
                                  <FontAwesomeIcon
                                    icon={faPencilSquare}
                                    style={{ color: "white" }}
                                  />
                               </Link>
                                <form
                                  class="float-left pl-2 me-2"
                                  action="https://fit-buddy.io/admin/admin/menu-items/1615"
                                  method="POST"
                                >
                                  <input
                                    type="hidden"
                                    name="_method"
                                    value="DELETE"
                                  />
                                  <input
                                    type="hidden"
                                    name="_token"
                                    value="C4KWMkgrCT3CJNo8uJLXYiLCgDcL5LvFf7KFfBul"
                                  />
                                  <button
                                    class="btn btn-sm btn-icon btn-danger"
                                    data-toggle="tooltip"
                                    data-placement="top"
                                    title=""
                                    data-original-title="Delete"
                                  >
                                    {" "}
                                    <FontAwesomeIcon
                                      icon={faTrashAlt}
                                      style={{ color: "white" }}
                                    />
                                  </button>
                                </form>
                              </td>
                            </tr>
                            <tr>
                              <td>16</td>
                              <td>Gavin Joyce</td>
                              <td>Seller</td>
                              <td>Edinburgh</td>
                              <td>42</td>
                              <td>2010/12/22</td>
                              <td class="d-flex">
                               <Link
                                  to=""
                                  class="btn btn-sm btn-icon me-2
                                                              float-left btn-info"
                                  data-toggle="tooltip"
                                  data-placement="top"
                                  title=""
                                  data-original-title="View"
                                >
                                  <FontAwesomeIcon
                                    icon={faEye}
                                    style={{ color: "white" }}
                                  />
                               </Link>
                               <Link
                                  to=""
                                  class="btn btn-sm btn-icon float-left btn-primary me-2"
                                  data-toggle="tooltip"
                                  data-placement="top"
                                  title=""
                                  data-original-title="Edit"
                                >
                                  {" "}
                                  <FontAwesomeIcon
                                    icon={faPencilSquare}
                                    style={{ color: "white" }}
                                  />
                               </Link>
                                <form
                                  class="float-left pl-2 me-2"
                                  action="https://fit-buddy.io/admin/admin/menu-items/1615"
                                  method="POST"
                                >
                                  <input
                                    type="hidden"
                                    name="_method"
                                    value="DELETE"
                                  />
                                  <input
                                    type="hidden"
                                    name="_token"
                                    value="C4KWMkgrCT3CJNo8uJLXYiLCgDcL5LvFf7KFfBul"
                                  />
                                  <button
                                    class="btn btn-sm btn-icon btn-danger"
                                    data-toggle="tooltip"
                                    data-placement="top"
                                    title=""
                                    data-original-title="Delete"
                                  >
                                    {" "}
                                    <FontAwesomeIcon
                                      icon={faTrashAlt}
                                      style={{ color: "white" }}
                                    />
                                  </button>
                                </form>
                              </td>
                            </tr>
                            <tr>
                              <td>17</td>
                              <td>Brenden Wagner</td>
                              <td>Seller</td>
                              <td>San Francisco</td>
                              <td>28</td>
                              <td>2011/06/07</td>
                              <td class="d-flex">
                               <Link
                                  to=""
                                  class="btn btn-sm btn-icon me-2
                                                              float-left btn-info"
                                  data-toggle="tooltip"
                                  data-placement="top"
                                  title=""
                                  data-original-title="View"
                                >
                                  <FontAwesomeIcon
                                    icon={faEye}
                                    style={{ color: "white" }}
                                  />
                               </Link>
                               <Link
                                  to=""
                                  class="btn btn-sm btn-icon float-left btn-primary me-2"
                                  data-toggle="tooltip"
                                  data-placement="top"
                                  title=""
                                  data-original-title="Edit"
                                >
                                  {" "}
                                  <FontAwesomeIcon
                                    icon={faPencilSquare}
                                    style={{ color: "white" }}
                                  />
                               </Link>
                                <form
                                  class="float-left pl-2 me-2"
                                  action="https://fit-buddy.io/admin/admin/menu-items/1615"
                                  method="POST"
                                >
                                  <input
                                    type="hidden"
                                    name="_method"
                                    value="DELETE"
                                  />
                                  <input
                                    type="hidden"
                                    name="_token"
                                    value="C4KWMkgrCT3CJNo8uJLXYiLCgDcL5LvFf7KFfBul"
                                  />
                                  <button
                                    class="btn btn-sm btn-icon btn-danger"
                                    data-toggle="tooltip"
                                    data-placement="top"
                                    title=""
                                    data-original-title="Delete"
                                  >
                                    {" "}
                                    <FontAwesomeIcon
                                      icon={faTrashAlt}
                                      style={{ color: "white" }}
                                    />
                                  </button>
                                </form>
                              </td>
                            </tr>
                            <tr>
                              <td>18</td>
                              <td>Fiona Green</td>
                              <td>Seller</td>
                              <td>San Francisco</td>
                              <td>48</td>
                              <td>2010/03/11</td>
                              <td class="d-flex">
                               <Link
                                  to=""
                                  class="btn btn-sm btn-icon me-2
                                                              float-left btn-info"
                                  data-toggle="tooltip"
                                  data-placement="top"
                                  title=""
                                  data-original-title="View"
                                >
                                  <FontAwesomeIcon
                                    icon={faEye}
                                    style={{ color: "white" }}
                                  />
                               </Link>
                               <Link
                                  to=""
                                  class="btn btn-sm btn-icon float-left btn-primary me-2"
                                  data-toggle="tooltip"
                                  data-placement="top"
                                  title=""
                                  data-original-title="Edit"
                                >
                                  {" "}
                                  <FontAwesomeIcon
                                    icon={faPencilSquare}
                                    style={{ color: "white" }}
                                  />
                               </Link>
                                <form
                                  class="float-left pl-2 me-2"
                                  action="https://fit-buddy.io/admin/admin/menu-items/1615"
                                  method="POST"
                                >
                                  <input
                                    type="hidden"
                                    name="_method"
                                    value="DELETE"
                                  />
                                  <input
                                    type="hidden"
                                    name="_token"
                                    value="C4KWMkgrCT3CJNo8uJLXYiLCgDcL5LvFf7KFfBul"
                                  />
                                  <button
                                    class="btn btn-sm btn-icon btn-danger"
                                    data-toggle="tooltip"
                                    data-placement="top"
                                    title=""
                                    data-original-title="Delete"
                                  >
                                    {" "}
                                    <FontAwesomeIcon
                                      icon={faTrashAlt}
                                      style={{ color: "white" }}
                                    />
                                  </button>
                                </form>
                              </td>
                            </tr>
                            <tr>
                              <td>19</td>
                              <td>Bruno Nash</td>
                              <td>Seller</td>
                              <td>London</td>
                              <td>38</td>
                              <td>2011/05/03</td>
                              <td class="d-flex">
                               <Link
                                  to=""
                                  class="btn btn-sm btn-icon me-2
                                                              float-left btn-info"
                                  data-toggle="tooltip"
                                  data-placement="top"
                                  title=""
                                  data-original-title="View"
                                >
                                  <FontAwesomeIcon
                                    icon={faEye}
                                    style={{ color: "white" }}
                                  />
                               </Link>
                               <Link
                                  to=""
                                  class="btn btn-sm btn-icon float-left btn-primary me-2"
                                  data-toggle="tooltip"
                                  data-placement="top"
                                  title=""
                                  data-original-title="Edit"
                                >
                                  {" "}
                                  <FontAwesomeIcon
                                    icon={faPencilSquare}
                                    style={{ color: "white" }}
                                  />
                               </Link>
                                <form
                                  class="float-left pl-2 me-2"
                                  action="https://fit-buddy.io/admin/admin/menu-items/1615"
                                  method="POST"
                                >
                                  <input
                                    type="hidden"
                                    name="_method"
                                    value="DELETE"
                                  />
                                  <input
                                    type="hidden"
                                    name="_token"
                                    value="C4KWMkgrCT3CJNo8uJLXYiLCgDcL5LvFf7KFfBul"
                                  />
                                  <button
                                    class="btn btn-sm btn-icon btn-danger"
                                    data-toggle="tooltip"
                                    data-placement="top"
                                    title=""
                                    data-original-title="Delete"
                                  >
                                    {" "}
                                    <FontAwesomeIcon
                                      icon={faTrashAlt}
                                      style={{ color: "white" }}
                                    />
                                  </button>
                                </form>
                              </td>
                            </tr>
                            <tr>
                              <td>20</td>
                              <td>Finn Camacho</td>
                              <td>Seller</td>
                              <td>San Francisco</td>
                              <td>47</td>
                              <td>2009/07/07</td>
                              <td class="d-flex">
                               <Link
                                  to=""
                                  class="btn btn-sm btn-icon me-2
                                                              float-left btn-info"
                                  data-toggle="tooltip"
                                  data-placement="top"
                                  title=""
                                  data-original-title="View"
                                >
                                  <FontAwesomeIcon
                                    icon={faEye}
                                    style={{ color: "white" }}
                                  />
                               </Link>
                               <Link
                                  to=""
                                  class="btn btn-sm btn-icon float-left btn-primary me-2"
                                  data-toggle="tooltip"
                                  data-placement="top"
                                  title=""
                                  data-original-title="Edit"
                                >
                                  {" "}
                                  <FontAwesomeIcon
                                    icon={faPencilSquare}
                                    style={{ color: "white" }}
                                  />
                               </Link>
                                <form
                                  class="float-left pl-2 me-2"
                                  action="https://fit-buddy.io/admin/admin/menu-items/1615"
                                  method="POST"
                                >
                                  <input
                                    type="hidden"
                                    name="_method"
                                    value="DELETE"
                                  />
                                  <input
                                    type="hidden"
                                    name="_token"
                                    value="C4KWMkgrCT3CJNo8uJLXYiLCgDcL5LvFf7KFfBul"
                                  />
                                  <button
                                    class="btn btn-sm btn-icon btn-danger"
                                    data-toggle="tooltip"
                                    data-placement="top"
                                    title=""
                                    data-original-title="Delete"
                                  >
                                    {" "}
                                    <FontAwesomeIcon
                                      icon={faTrashAlt}
                                      style={{ color: "white" }}
                                    />
                                  </button>
                                </form>
                              </td>
                            </tr>
                            <tr>
                              <td>21</td>
                              <td>Cara Stevens</td>
                              <td>Seller</td>
                              <td>New York</td>
                              <td>46</td>
                              <td>2011/12/06</td>
                              <td class="d-flex">
                               <Link
                                  to=""
                                  class="btn btn-sm btn-icon me-2
                                                              float-left btn-info"
                                  data-toggle="tooltip"
                                  data-placement="top"
                                  title=""
                                  data-original-title="View"
                                >
                                  <FontAwesomeIcon
                                    icon={faEye}
                                    style={{ color: "white" }}
                                  />
                               </Link>
                               <Link
                                  to=""
                                  class="btn btn-sm btn-icon float-left btn-primary me-2"
                                  data-toggle="tooltip"
                                  data-placement="top"
                                  title=""
                                  data-original-title="Edit"
                                >
                                  {" "}
                                  <FontAwesomeIcon
                                    icon={faPencilSquare}
                                    style={{ color: "white" }}
                                  />
                               </Link>
                                <form
                                  class="float-left pl-2 me-2"
                                  action="https://fit-buddy.io/admin/admin/menu-items/1615"
                                  method="POST"
                                >
                                  <input
                                    type="hidden"
                                    name="_method"
                                    value="DELETE"
                                  />
                                  <input
                                    type="hidden"
                                    name="_token"
                                    value="C4KWMkgrCT3CJNo8uJLXYiLCgDcL5LvFf7KFfBul"
                                  />
                                  <button
                                    class="btn btn-sm btn-icon btn-danger"
                                    data-toggle="tooltip"
                                    data-placement="top"
                                    title=""
                                    data-original-title="Delete"
                                  >
                                    {" "}
                                    <FontAwesomeIcon
                                      icon={faTrashAlt}
                                      style={{ color: "white" }}
                                    />
                                  </button>
                                </form>
                              </td>
                            </tr>
                            <tr>
                              <td>22</td>
                              <td>Michael Bruce</td>
                              <td>Seller</td>
                              <td>Singapore</td>
                              <td>29</td>
                              <td>2011/06/27</td>
                              <td class="d-flex">
                               <Link
                                  to=""
                                  class="btn btn-sm btn-icon me-2
                                                              float-left btn-info"
                                  data-toggle="tooltip"
                                  data-placement="top"
                                  title=""
                                  data-original-title="View"
                                >
                                  <FontAwesomeIcon
                                    icon={faEye}
                                    style={{ color: "white" }}
                                  />
                               </Link>
                               <Link
                                  to=""
                                  class="btn btn-sm btn-icon float-left btn-primary me-2"
                                  data-toggle="tooltip"
                                  data-placement="top"
                                  title=""
                                  data-original-title="Edit"
                                >
                                  {" "}
                                  <FontAwesomeIcon
                                    icon={faPencilSquare}
                                    style={{ color: "white" }}
                                  />
                               </Link>
                                <form
                                  class="float-left pl-2 me-2"
                                  action="https://fit-buddy.io/admin/admin/menu-items/1615"
                                  method="POST"
                                >
                                  <input
                                    type="hidden"
                                    name="_method"
                                    value="DELETE"
                                  />
                                  <input
                                    type="hidden"
                                    name="_token"
                                    value="C4KWMkgrCT3CJNo8uJLXYiLCgDcL5LvFf7KFfBul"
                                  />
                                  <button
                                    class="btn btn-sm btn-icon btn-danger"
                                    data-toggle="tooltip"
                                    data-placement="top"
                                    title=""
                                    data-original-title="Delete"
                                  >
                                    {" "}
                                    <FontAwesomeIcon
                                      icon={faTrashAlt}
                                      style={{ color: "white" }}
                                    />
                                  </button>
                                </form>
                              </td>
                            </tr>
                            <tr>
                              <td>23</td>
                              <td>Donna Snider</td>
                              <td>Agent</td>
                              <td>New York</td>
                              <td>27</td>
                              <td>2011/01/25</td>
                              <td class="d-flex">
                               <Link
                                  to=""
                                  class="btn btn-sm btn-icon me-2
                                                              float-left btn-info"
                                  data-toggle="tooltip"
                                  data-placement="top"
                                  title=""
                                  data-original-title="View"
                                >
                                  <FontAwesomeIcon
                                    icon={faEye}
                                    style={{ color: "white" }}
                                  />
                               </Link>
                               <Link
                                  to=""
                                  class="btn btn-sm btn-icon float-left btn-primary me-2"
                                  data-toggle="tooltip"
                                  data-placement="top"
                                  title=""
                                  data-original-title="Edit"
                                >
                                  {" "}
                                  <FontAwesomeIcon
                                    icon={faPencilSquare}
                                    style={{ color: "white" }}
                                  />
                               </Link>
                                <form
                                  class="float-left pl-2 me-2   "
                                  action="https://fit-buddy.io/admin/admin/menu-items/1615"
                                  method="POST"
                                >
                                  <input
                                    type="hidden"
                                    name="_method"
                                    value="DELETE"
                                  />
                                  <input
                                    type="hidden"
                                    name="_token"
                                    value="C4KWMkgrCT3CJNo8uJLXYiLCgDcL5LvFf7KFfBul"
                                  />
                                  <button
                                    class="btn btn-sm btn-icon btn-danger"
                                    data-toggle="tooltip"
                                    data-placement="top"
                                    title=""
                                    data-original-title="Delete"
                                  >
                                    {" "}
                                    <FontAwesomeIcon
                                      icon={faTrashAlt}
                                      style={{ color: "white" }}
                                    />
                                  </button>
                                </form>
                              </td>
                            </tr>
                          </tbody>
                        </table>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </main>
        {/* <!-- end::main-content --> */}
      </div>
    </>
  );
};

export default PropertyListing;
