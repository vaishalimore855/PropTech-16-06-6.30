import React from "react";
import logo from "../../assets/media/image/logo.png";
import logo_sm from "../../assets/media/image/logo-sm.png";
import logo_dark from "../../assets/media/image/logo-dark.png";
//icons
import "bootstrap/dist/css/bootstrap.min.css";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faBarChart, faSearch, faUser } from "@fortawesome/free-solid-svg-icons";
import { faCog } from "@fortawesome/free-solid-svg-icons";
import { faSignOutAlt } from "@fortawesome/free-solid-svg-icons";
import { faBars } from "@fortawesome/free-solid-svg-icons/faBars";
import { faExpand } from "@fortawesome/free-solid-svg-icons/faExpand";
import { faTh, faThLarge } from "@fortawesome/free-solid-svg-icons";
import { faComment } from "@fortawesome/free-solid-svg-icons";
import { faBell } from "@fortawesome/free-solid-svg-icons";
import { Link, useNavigate } from "react-router-dom";
import { faChartBar, faChartBarAlt } from '@fortawesome/free-solid-svg-icons';
import { faFolder, faFile } from '@fortawesome/free-solid-svg-icons';
import { faMessageCircle } from '@fortawesome/free-solid-svg-icons';
import { faGlobe } from '@fortawesome/free-solid-svg-icons';
import { faAngleUp } from '@fortawesome/free-solid-svg-icons';


import Header from "../admin/Header";
const Sidebar = () => {
  var navigate = useNavigate();
  const handleClick = () => {
    navigate("/profile");
    navigate("/homepage");
    navigate("/buyer");
    navigate("/investor");
    navigate("/sellers");
    navigate("/property-listing");
    navigate("/document-verification");
  };
  return (
    <>
      {/* <!-- begin::navigation --> */}
      <div
        className="navigation"
        style={{ overflow: "auto", height: "100vh", position: "fixed" }}
      >
        {/* <!-- begin::logo --> */}
        <div id="logo">
          <Link href="index.html">
            <img className="logo" src={logo} alt="logo" />
            {/* <img className="logo-sm" src={logo_sm} alt="small logo" />
            <img className="logo-dark" src={logo_dark} alt="dark logo" /> */}
          </Link>
        </div>
        {/* <!-- end::logo --> */}

        {/* <!-- begin::navigation header --> */}
        <header className="navigation-header">
          <figure className="avatar avatar-state-success">
            <img
              src="https://via.placeholder.com/128X128"
              className="rounded-circle"
              alt="image"
            />
          </figure>
          <div>
            <h5>Nikos Pedlow</h5>
            <p className="text-muted">Administrator</p>
            <ul className="nav">
              <li className="nav-item">
                <Link
                  to="/profile"
                  className="btn nav-link bg-info-bright"
                  title="Profile"
                  data-toggle="tooltip"
                >
                  {/* <i data-feather="user"></i> */}
                  <FontAwesomeIcon icon={faUser} />
                </Link>
              </li>
              <li className="nav-item">
                <Link
                  to="/"
                  className="btn nav-link bg-success-bright"
                  title="Settings"
                  data-toggle="tooltip"
                >
                  {/* <i data-feather="settings"></i> */}
                  <FontAwesomeIcon icon={faCog} />
                </Link>
              </li>
              <li className="nav-item">
                <Link
                  to="/"
                  className="btn nav-link bg-danger-bright"
                  title="Logout"
                  data-toggle="tooltip"
                >
                  {/* <i data-feather="log-out"></i> */}
                  <FontAwesomeIcon icon={faSignOutAlt} />
                </Link>
              </li>
            </ul>
          </div>
        </header>
        {/* end::navigation header  */}
        <div className="navigation-menu-body">
          <ul>
            <li>
              <Link to="/homepage" >
              <FontAwesomeIcon icon={faChartBar}  className="me-3 nav-link-icon"/>
                {/* <i className="nav-link-icon" data-feather="bar-chart-2"></i> */}
                <span>Dashboard</span>
              </Link>
            </li>

            <li>
              <Link href="#">
                {/* <i className="nav-link-icon" data-feather="globe"></i> */}
                <FontAwesomeIcon icon={faGlobe} className="me-3 nav-link-icon" />
                <span>User Management</span>
                <FontAwesomeIcon icon={faAngleUp} className="sub-menu-arrow" />
              </Link>
              <ul>
                <li>
                  <Link to="/buyer">Buyers</Link>
                </li>
                <li>
                  <Link to="/sellers">Sellers</Link>
                </li>
                <li>
                  <Link to="/investor">Investors</Link>
                </li>
              </ul>
            </li>
            <li>
              <Link to="/property-listing">
                <i className="ti-agenda nav-link-icon"></i>
                <span>Property Listing</span>
              </Link>
            </li>
            <li>
              <Link to="/document-verification ">
               
                <FontAwesomeIcon icon={faComment} className="me-3" />
                <span>Request</span>
              </Link>
            </li>
            <li>
              <Link href="file-manager.html">
              <FontAwesomeIcon icon={faFile}className="me-3" />
                <span>File Manager</span>
              </Link>
            </li>
          </ul>
        </div>
      </div>
      {/* end::navigation  */}
      <div id="main">
        <Header />
      </div>
    </>
  );
};

export default Sidebar;
