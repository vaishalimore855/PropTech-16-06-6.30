import React from 'react'
import { lazy,Suspense } from 'react';
import ResetPassword from '../Components/auth/ResetPassword';

import MainLayout from '../Components/Sidebar/SidebarLayout';
import { useRoutes } from 'react-router-dom';


const Loader = (Component)=> (props) =>
(
    <Suspense fallback={<Loader/>}>
        <Component  {...props}/>
    </Suspense>
);


const Home = Loader(lazy(() => import('../Components/admin/Home/Home')));
const Profile = Loader(lazy(() => import('../Components/admin/Profile')));
const Buyer = Loader(lazy(() => import('../Components/admin/Buyer/Buyer')));
const AddBuyer = Loader(lazy(() => import('../Components/admin/Buyer/AddBuyer')));
const EditBuyer = Loader(lazy(() => import('../Components/admin/Buyer/EditBuyer')));
const AddInvestorForm = Loader(lazy(() => import('../Components/admin/Investor/AddInvestorForm')));
const Investors = Loader(lazy(() => import('../Components/admin/Investor/Investors')));
const EditInvestor = Loader(lazy(() => import('../Components/admin/Investor/EditInvestor')));
const Sellers = Loader(lazy(() => import('../Components/admin/Sellers/Sellers')));
const AddSellers = Loader(lazy(() => import('../Components/admin/Sellers/AddSellers')));
const EditSeller = Loader(lazy(() => import('../Components/admin/Sellers/EditSeller')));
const PropertyListing = Loader(lazy(() => import('../Components/admin/PropertyListing/PropertyListing')));
const AddProperty = Loader(lazy(() => import('../Components/admin/PropertyListing/AddProperty')));
const DocVerification = Loader(lazy(() => import('../Components/admin/DocumentVerification/DocVerification')));


// const Home = Loader(lazy(() => import('.../Components/admin/Home/Home')));




function Router() {

    {
        let element = useRoutes([
            //   {
            //     element: <AuthLayout />,
            //     children: [
            //       { path: "/", element: <Login /> },
            //       { path: "signup", element: <SignUp /> }
            //     ]
            //   },
            {
                element: <MainLayout />,
                children: [
                    { path: "/homepage", element: <Home /> },
                    { path:"/profile", element: <Profile /> },
                    { path:"/buyer", element: <Buyer /> },
                    { path:"/add-buyer", element: <AddBuyer /> },
                    { path:"/edit-buyer", element: <EditBuyer /> },
                    { path:"/add-investor", element: <AddInvestorForm /> },
                    { path:"/edit-investor", element: <EditInvestor /> },
                    { path:"/investor", element: <Investors /> },
                    { path:"/sellers", element: <Sellers /> },
                    { path:"/add-sellers", element: <AddSellers /> },
                    { path:"/edit-sellers", element: <EditSeller /> },
                    { path:"/property-listing", element: <PropertyListing /> },
                    { path:"/add-property", element: <AddProperty /> },
                    { path:"/document-verification", element: <DocVerification /> },
                   

                ]
            }
        ]);

        return element;
    }
}

export default Router