import logo from './logo.svg';
import './App.css';
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Login from './Components/auth/login';

function App() {
  return (
    <BrowserRouter>
      <Login />
      <Routes>
        {/* <Route path="/Analyse" element={<Analyse />}></Route>  */}
      </Routes>
    </BrowserRouter>
  );
}

export default App;
