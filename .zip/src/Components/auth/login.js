import React from 'react'

function Login() {
    
  return (
    <div>
       <h1 className='text-center'>PropTech</h1> 
    </div>
  )
}

export default Login