import React from "react";

const ViewBuyer = () => {
  return (
    <div className="rtl">
      <div id="main">
        <div className="main-content">
          <div className="container">
            <div className="page-header">
              <h4>Buyer Details</h4>
              <nav aria-label="breadcrumb">
                <ol className="breadcrumb">
                  <li className="breadcrumb-item">
                    <a href="#">Home</a>
                  </li>
                  <li className="breadcrumb-item">
                    <a href="#">User Management</a>
                  </li>
                  <li className="breadcrumb-item">
                    <a href="#">Buyers</a>
                  </li>
                  <li className="breadcrumb-item active" aria-current="page">
                    Buyer Details
                  </li>
                </ol>
              </nav>
            </div>
            <div className="row">
              <div className="col-md-12">
                <div className="card">
                  <h2
                    className="mt-5 mb-3"
                    style={{ marginLeft: "40px", fontWeight: "bold" }}
                  >
                    Buyer Name
                  </h2>
                  <div className="card-body d-flex">
                    <div className="view-document-main col-lg-6">
                      <dl className="row">
                        <dt className="col-5">Name:</dt>
                        <dd className="col-7">XYZ</dd>
                      </dl>
                      {/* Rest of the dl elements */}
                    </div>
                    <div className="view-document-main col-lg-6">
                      <dl className="row">
                        <dt className="col-5">Adhar Card:</dt>
                        <dd className="col-7">
                          <div
                            style={{
                              width: "200px",
                              height: "200px",
                              border: "1px black solid",
                              padding: "10px",
                              marginRight: "20px",
                            }}
                          >
                            <img
                              src="../default/assets/media/image/dumy-doc-1.png"
                              alt=""
                              width="100%"
                              height="100%"
                            />
                          </div>
                        </dd>
                      </dl>
                      {/* Rest of the dl elements */}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ViewBuyer;
