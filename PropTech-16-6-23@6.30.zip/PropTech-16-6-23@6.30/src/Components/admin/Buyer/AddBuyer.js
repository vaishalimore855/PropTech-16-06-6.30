import React from "react";
import { Link } from "react-router-dom";
const AddBuyer = () => {
  return (
    <div className="rtl">
      <div id="main">
        <div className="main-content">
          <div className="container">
            {/* <!-- begin::page-header --> */}
            <div className="page-header mt-5">
              <h4>Add Buyer</h4>
              <nav aria-label="breadcrumb">
                <ol className="breadcrumb">
                  <li className="breadcrumb-item">
                    <Link to="/homepage">Home</Link>
                  </li>
                  <li className="breadcrumb-item">
                    <Link to="#">User Management Screen</Link>
                  </li>
                  <li className="breadcrumb-item">
                    <Link to="#">Buyers</Link>
                  </li>
                  <li className="breadcrumb-item active" aria-current="page">
                    Add Buyer
                  </li>
                </ol>
              </nav>
            </div>
            {/* <!-- end::page-header --> */}

            <div className="row">
              <div className="col-md-12">
                <div className="card">
                  <div className="card-body">
                    <form >
                      <div className="row">
                        <div className="col-md-4 mb-3">
                          <label for="validationCustom01">Full Name</label>
                          <input
                            type="text"
                            className="form-control"
                            id="validationCustom01"
                            placeholder="enter your full name"
                            required=""
                          />
                          <div className="valid-feedback">Looks good!</div>
                        </div>
                        <div className="col-md-4 mb-3">
                          <label for="validationCustom02">Contact Number</label>
                          <input
                            type="text"
                            data-input-mask="phone"
                            className="form-control"
                            id="validationCustom02"
                            placeholder="9087654321"
                            required=""
                          />
                          <div className="valid-feedback">Looks good!</div>
                        </div>
                        <div className="col-md-4 mb-3">
                          <label for="validationCustom03">Budget</label>
                          <input
                            type="text"
                            className="form-control"
                            id="validationCustom03"
                            placeholder="enter your Budget"
                            required=""
                          />
                          <div className="valid-feedback">Looks good!</div>
                        </div>
                      </div>
                      <div className="row">
                        <div className="col-md-6 mb-3">
                          <label for="validationCustom04">
                            Location Preferences
                          </label>
                          <input
                            type="text"
                            className="form-control"
                            id="validationCustom04"
                            placeholder=""
                            required=""
                          />
                          <div className="invalid-feedback">
                            Please provide a valid location.
                          </div>
                        </div>
                        <div className="col-md-3 mt-4">
                          <label for="validationCustom04">Property Type</label>
                          <select className="select2-example">
                            <option>Select</option>
                            <option value="House">House</option>
                            <option value="Apartment">Apartment</option>
                            <option value="Land">Land</option>
                          </select>
                          <div className="invalid-feedback"></div>
                        </div>
                        <div className="col-md-3 mb-3">
                          <label for="validationCustom06">
                            Preferred Square Footage
                          </label>
                          <input
                            type="text"
                            className="form-control"
                            id="validationCustom06"
                            placeholder=""
                            required=""
                          />
                          <div className="invalid-feedback"></div>
                        </div>
                        <div className="col-md-6 mb-3">
                          <label for="validationCustom05">Amenities</label>
                          <textarea
                            className="form-control"
                            id="validationCustom05"
                            rows="3"
                          ></textarea>

                          <div className="invalid-feedback"></div>
                        </div>
                        <div className="col-md-6 mb-3">
                          <label for="validationCustom07">
                            Preferred Neighborhood Features
                          </label>
                          <textarea
                            className="form-control"
                            id="validationCustom07"
                            rows="3"
                          ></textarea>
                          <div className="invalid-feedback"></div>
                        </div>
                        <div className="col-md-3 mb-3 mt-4">
                          <label for="validationCustom08">Financing</label>
                          <select className="select2-example">
                            <option value="Cash">Cash</option>
                            <option value=" Mortgage"> Mortgage</option>
                            <option value="Other Options">Other Options</option>
                          </select>
                          <div className="invalid-feedback"></div>
                        </div>
                        <div className="col-md-6 mb-3">
                          <label for="validationCustom09">
                            Additional Comments/Notes
                          </label>
                          <textarea
                            className="form-control"
                            id="validationCustom09"
                            rows="3"
                          ></textarea>
                          <div className="invalid-feedback"></div>
                        </div>
                      </div>
                      <div className="form-group">
                        <div className="form-check">
                          <input
                            className="form-check-input"
                            type="checkbox"
                            value=""
                            id="invalidCheck"
                            required=""
                          />
                          <label
                            className="form-check-label"
                            for="invalidCheck"
                          >
                            Agree to terms and conditions
                          </label>
                          <div className="invalid-feedback">
                            You must agree before submitting.
                          </div>
                        </div>
                      </div>
                      <button className="btn btn-primary" type="submit">
                        Submit{" "}
                      </button>
                    </form>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        {/* <!-- end::main-content --> */}
      </div>
      {/* <!-- end::main --> */}
    </div>
  );
};

export default AddBuyer;
