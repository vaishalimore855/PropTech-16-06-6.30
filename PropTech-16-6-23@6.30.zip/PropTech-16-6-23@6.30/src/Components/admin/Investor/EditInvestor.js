import React from "react";
import { Link, useNavigate } from "react-router-dom";
const EditInvestor = () => {
  var navigate = useNavigate();
  const handleClick = () => {
     navigate("/homepage");
    navigate("/investor");
    
  };
  return (
    <div className="rtl">
      {/* <!-- begin::main--> */}
      <div id="main">
        {/* <!-- begin::main-content --> */}
        <div className="main-content">
          <div className="container">
            {/* <!-- begin::page-header --> */}
            <div className="page-header mt-5">
              <h4>Edit Investor</h4>
              <nav aria-label="breadcrumb">
                <ol className="breadcrumb">
                  <li className="breadcrumb-item">
                    <Link to="/homepage" >Home</Link>
                  </li>
                  <li className="breadcrumb-item">
                    <Link to="#">User Management</Link>
                  </li>
                  <li className="breadcrumb-item">
                    <Link to="/investor">Investors</Link>
                  </li>
                  <li className="breadcrumb-item active" aria-current="page">
                    Edit Investor
                  </li>
                </ol>
              </nav>
            </div>
            {/* <!-- end::page-header --> */}
            <div className="row">
              <div className="col-md-12">
                <div className="card">
                  <div className="card-body">
                    <form className="needs-validation" novalidate="">
                      <div className="form-row">
                        <div className="col-md-4 mb-3">
                          <label for="validationCustom01">Full Name</label>
                          <input
                            type="text"
                            className="form-control"
                            id="validationCustom01"
                            placeholder="enter your full name"
                            required=""
                          />
                          <div className="valid-feedback">Looks good!</div>
                        </div>
                        <div className="col-md-4 mb-3">
                          <label for="validationCustom02">Contact Number</label>
                          <input
                            type="text"
                            data-input-mask="phone"
                            className="form-control"
                            id="validationCustom02"
                            placeholder="9087654321"
                            required=""
                          />
                          <div className="valid-feedback">Looks good!</div>
                        </div>
                        <div className="col-md-4 mb-3">
                          <label for="validationCustom03">Email Address</label>
                          <input
                            type="email"
                            className="form-control"
                            id="validationCustom03"
                            placeholder=""
                            required=""
                          />
                          <div className="valid-feedback">Looks good!</div>
                        </div>
                      </div>
                      <div className="form-row">
                        <div className="col-md-6 mb-3">
                          <label for="validationCustom04">Address</label>
                          <input
                            type="text"
                            className="form-control"
                            id="validationCustom04"
                            placeholder=""
                            required=""
                          />
                          <div className="invalid-feedback">
                            Please provide a valid location.
                          </div>
                        </div>

                        <div className="col-md-6 mb-3">
                          <label for="validationCustom06">
                            Company/Agency Name (if applicable)
                          </label>
                          <input
                            type="text"
                            className="form-control"
                            id="validationCustom06"
                            placeholder=""
                            required=""
                          />
                          <div className="invalid-feedback"></div>
                        </div>
                        <div className="col-md-6 mb-3">
                          <label for="validationCustom05">
                            Verification Status
                          </label>
                          <input
                            type="text"
                            className="form-control"
                            id="validationCustom05"
                            placeholder=""
                            required=""
                          />

                          {/* <!-- <input type="text" className="form-control" id="validationCustom05" placeholder="enter amenities"required=""> --> */}
                          <div className="invalid-feedback"></div>
                        </div>
                      </div>
                      <div className="form-group">
                        <div className="form-check">
                          <input
                            className="form-check-input"
                            type="checkbox"
                            value=""
                            id="invalidCheck"
                            required=""
                          />
                          <label
                            className="form-check-label"
                            for="invalidCheck"
                          >
                            Agree to terms and conditions
                          </label>
                          <div className="invalid-feedback">
                            You must agree before submitting.
                          </div>
                        </div>
                      </div>
                      <button className="btn btn-primary" type="submit">
                        Submit{" "}
                      </button>
                    </form>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        {/* <!-- end::main-content --> */}
      </div>
      {/* <!-- end::main --> */}
    </div>
  );
};

export default EditInvestor;
