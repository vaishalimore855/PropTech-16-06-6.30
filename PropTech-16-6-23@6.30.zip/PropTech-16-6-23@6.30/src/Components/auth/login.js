import React, { useState } from "react";
import Profile from "../admin/Profile";
import { useNavigate } from "react-router-dom";
import "bootstrap/dist/css/bootstrap.min.css";

function Login() {
  var navigate1 = useNavigate();
  const handleClick1 = () => {
    navigate1("/sidebar");
  };
  var navigate2 = useNavigate();
  const handleClick2 = () => {
    navigate2("/reset-password");
  };

  return (
    <div className="form-membership">
      <div className="form-wrapper">
        {/* logo  */}
        <div id="logo">
          <h2>PropTech</h2>
        </div>
        {/* ./ logo  */}
        <h5 style={{ textAlign: "center" }}>Log In</h5>
        {/* <form  */}
        <form>
          <div className="form-group mb-3">
            <input
              type="text"
              className="form-control"
              placeholder="Username or email"
              required
              autofocus
            />
          </div>
          <div className="form-group mb-3">
            <input
              type="password"
              className="form-control"
              placeholder="Password"
              required
            />
          </div>
          <div className="form-group d-flex justify-content-between mb-3 mt-2">
            <div className="custom-control custom-checkbox ">
              <input
                type="checkbox"
                id="exampleCheckbox"
                className="custom-control-input me-2 "
              />
              <label className="custom-control-label" for="customCheck1">
                Remember me
              </label>
            </div>
            <a href="/reset-password" onClick={() => handleClick2()}>
              Reset password
            </a>
          </div>
          <button
            className="btn btn-primary btn-block "
            onClick={() => handleClick1()}
          >
            Log In
          </button>
          {/* <hr /> */}
          {/* <p className="text-muted">Don't have an account?</p>
          <a href="./registration.js" />
          <a href="./register.html" className="btn btn-outline-light btn-sm" style={{ display: "flex", justifyContent: "center", alignItems: 'center' }}>Register now!</a> */}
        </form>
        {/* ./ form */}
      </div>
    </div>
  );
}

export default Login;
