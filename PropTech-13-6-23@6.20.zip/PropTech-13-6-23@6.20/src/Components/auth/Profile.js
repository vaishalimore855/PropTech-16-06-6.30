import React from 'react'
import logo from "../../assets/media/image/logo.png"
import logo_sm from "../../assets/media/image/logo-sm.png"
import logo_dark from "../../assets/media/image/logo-dark.png"
//icons
import 'bootstrap/dist/css/bootstrap.min.css';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faUser } from '@fortawesome/free-solid-svg-icons';
import { faCog} from '@fortawesome/free-solid-svg-icons';
import { faSignOutAlt } from '@fortawesome/free-solid-svg-icons';

const Profile = () => {
  return (
    <>
      {/* <!-- begin::navigation --> */}
      <div className="navigation" style={{ overflow: "auto", height: "100vh", position: "fixed" }}>

        {/* <!-- begin::logo --> */}
        <div id="logo">
          
          <a href="index.html">
            <img className="logo" src={logo} alt="logo" />
            {/* <img className="logo-sm" src={logo_sm} alt="small logo" />
            <img className="logo-dark" src={logo_dark} alt="dark logo" /> */}
          </a>
        </div>
        {/* <!-- end::logo --> */}

        {/* <!-- begin::navigation header --> */}
        <header className="navigation-header">
          <figure className="avatar avatar-state-success">
            <img src="https://via.placeholder.com/128X128" className="rounded-circle" alt="image" />
          </figure>
          <div>
            <h5>Nikos Pedlow</h5>
            <p className="text-muted">Administrator</p>
            <ul className="nav">
              <li className="nav-item">
                <a href="profile.html" className="btn nav-link bg-info-bright" title="Profile" data-toggle="tooltip">
                  {/* <i data-feather="user"></i> */}
                  <FontAwesomeIcon icon={faUser} />
                </a>
              </li>
              <li className="nav-item">
                <a href="#" className="btn nav-link bg-success-bright" title="Settings" data-toggle="tooltip">
                  {/* <i data-feather="settings"></i> */}
                  <FontAwesomeIcon icon={faCog} />
                </a>
              </li>
              <li className="nav-item">
                <a href="login.html" className="btn nav-link bg-danger-bright" title="Logout" data-toggle="tooltip">
                  {/* <i data-feather="log-out"></i> */}
                  <FontAwesomeIcon icon={faSignOutAlt} />
                </a>
              </li>
            </ul>
          </div>
        </header>
        {/* end::navigation header  */}

        {/* begin::navigation menu  */}
        <div className="navigation-menu-body">
          <ul>
            <li className="navigation-divider"></li>
            <li>
              <a href="index.html">
                <i className="nav-link-icon" data-feather="bar-chart-2"></i>
                <span>Dashboard</span>
              </a>
              <ul>
                <li><a href="index.html">Dashboard</a></li>

              </ul>
            </li>
            <li>
              <a href="chat.html">
                <i className="nav-link-icon" data-feather="message-circle"></i>
                <span>Chat</span>
                <span className="badge badge-danger">2</span>
              </a>
            </li>
            <li>
              <a href="inbox.html">
                <i className="nav-link-icon" data-feather="mail"></i>
                <span>Mail</span>
                <span className="badge badge-success">2</span>
              </a>
            </li>
            <li>
              <a href="app-todo.html">
                <i className="nav-link-icon" data-feather="check-circle"></i>
                <span>Todo</span>
                <span className="badge badge-warning">2</span>
              </a>
            </li>
            <li>
              <a href="file-manager.html">
                <i className="nav-link-icon" data-feather="file"></i>
                <span>File Manager</span>
              </a>
            </li>
            <li>
              <a href="calendar.html">
                <i className="nav-link-icon" data-feather="calendar"></i>
                <span>Calendar</span>
              </a>
            </li>
            <li className="navigation-divider">UI Elements</li>
            <li>
              <a href="#">
                <i className="nav-link-icon" data-feather="monitor"></i>
                <span>Components</span>
              </a>
              <ul>
                <li>
                  <a href="#">Basic</a>
                  <ul>
                    <li><a href="alerts.html">Alert</a></li>
                    <li><a href="accordion.html">Accordion</a></li>
                    <li><a href="buttons.html">Buttons</a></li>
                    <li><a href="dropdown.html">Dropdown</a></li>
                    <li><a href="list-group.html">List Group</a></li>
                    <li><a href="pagination.html">Pagination</a></li>
                    <li><a href="typography.html">Typography</a></li>
                    <li><a href="media-object.html">Media Object</a></li>
                    <li><a href="progress.html">Progress</a></li>
                    <li><a href="modal.html">Modal</a></li>
                    <li><a href="spinners.html">Spinners</a></li>
                    <li><a href="navs.html">Navs</a></li>
                    <li><a href="tab.html">Tab</a></li>
                    <li><a href="tooltip.html">Tooltip</a></li>
                    <li><a href="popovers.html">Popovers</a></li>
                  </ul>
                </li>
                <li>
                  <a href="#">Cards</a>
                  <ul>
                    <li><a href="basic-cards.html">Basic Cards </a></li>
                    <li><a href="image-cards.html">Image Cards </a></li>
                    <li><a href="card-scroll.html">Card Scroll </a></li>
                    <li><a href="other-cards.html">Others </a></li>
                  </ul>
                </li>
                <li><a href="avatar.html">Avatar</a></li>
                <li><a href="icons.html">Icons</a></li>
                <li><a href="colors.html">Colors</a></li>
              </ul>
            </li>
            <li>
              <a href="#">
                <i className="nav-link-icon" data-feather="globe"></i>
                <span>Plugins</span>
              </a>
              <ul>
                <li><a href="sweet-alert.html">Sweet Alert</a></li>
                <li><a href="lightbox.html">Lightbox</a></li>
                <li><a href="toast.html">Toast</a></li>
                <li><a href="tour.html">Tour</a></li>
                <li><a href="slick-slide.html">Slick Slide</a></li>
                <li><a href="nestable.html">Nestable</a></li>
              </ul>
            </li>
            <li>
              <a href="#">
                <i className="nav-link-icon" data-feather="mouse-pointer"></i>
                <span>Forms</span>
              </a>
              <ul>
                <li><a href="basic-form.html">Form Layouts</a></li>
                <li><a href="custom-form.html">Custom Forms</a></li>
                <li><a href="advanced-form.html">Advanced Form</a></li>
                <li><a href="form-validation.html">Validation</a></li>
                <li><a href="form-wizard.html">Wizard</a></li>
                <li><a href="file-upload.html">File Upload</a></li>
                <li><a href="datepicker.html">Datepicker</a></li>
                <li><a href="timepicker.html">Timepicker</a></li>
                <li><a href="colorpicker.html">Colorpicker</a></li>
              </ul>
            </li>
            <li>
              <a href="#">
                <i className="nav-link-icon" data-feather="grid"></i>
                <span>Tables</span>
              </a>
              <ul>
                <li><a href="tables.html">Basic Tables</a></li>
                <li><a href="data-table.html">Datatable</a></li>
                <li><a href="responsive-table.html">Responsive Tables</a></li>
              </ul>
            </li>
            <li>
              <a href="#">
                <i className="nav-link-icon" data-feather="pie-chart"></i>
                <span>Charts</span>
              </a>
              <ul>
                <li><a href="apexchart.html">Apex</a></li>
                <li><a href="chartjs.html">Chartjs</a></li>
                <li><a href="justgage.html">Justgage</a></li>
                <li><a href="morsis.html">Morsis</a></li>
                <li><a href="peity.html">Peity</a></li>
              </ul>
            </li>
            <li>
              <a href="#">
                <i className="nav-link-icon" data-feather="map-pin"></i>
                <span>Maps</span>
              </a>
              <ul>
                <li><a href="google-map.html">Google</a></li>
                <li><a href="vector-map.html">Vector</a></li>
              </ul>
            </li>
            <li className="navigation-divider">Extras</li>
            <li>
              <a href="#">
                <i className="nav-link-icon" data-feather="user"></i>
                <span>Authentication</span>
              </a>
              <ul>
                <li><a href="login.html">Login</a></li>
                <li><a href="register.html">Register</a></li>
                <li><a href="recover-password.html">Recovery Password</a></li>
                <li><a href="lock-screen.html">Lock Screen</a></li>
              </ul>
            </li>
            <li className="open">
              <a href="#">
                <i className="nav-link-icon" data-feather="copy"></i>
                <span>Pages</span>
              </a>
              <ul>
                <li><a className="active" href="profile.html">Profile</a></li>
                <li><a href="timeline.html">Timeline</a></li>
                <li><a href="invoice.html">Invoice</a></li>

                <li><a href="pricing-table.html">Pricing Table</a></li>
                <li><a href="search-result.html">Search Result</a></li>
                <li>
                  <a href="#">Error Pages</a>
                  <ul>
                    <li><a href="404.html">404</a></li>
                    <li><a href="404-2.html">404 V2</a></li>
                    <li><a href="503.html">503</a></li>
                    <li><a href="mean-at-work.html">Mean at Work</a></li>
                  </ul>
                </li>
                <li><a href="blank-page.html">Starter Page</a></li>
              </ul>
            </li>
            <li>
              <a href="#">
                <i className="nav-link-icon" data-feather="send"></i>
                <span>Email Templates</span>
              </a>
              <ul>
                <li><a href="email-template-basic.html">Basic</a></li>
                <li><a href="email-template-alert.html">Alert</a></li>
                <li><a href="email-template-billing.html">Billing</a></li>
              </ul>
            </li>
            <li>
              <a href="#">
                <i className="nav-link-icon" data-feather="menu"></i>
                <span>Menu Level</span>
              </a>
              <ul>
                <li>
                  <a href="#">Menu Level</a>
                  <ul>
                    <li>
                      <a href="#">Menu Level </a>
                    </li>
                  </ul>
                </li>
              </ul>
            </li>
          </ul>
        </div>
        {/* end::navigation menu  */}

      </div>
      {/* end::navigation  */}


      {/* begin::main  */}
      <div id="main" style={{ position: "absolute", top: "0px", left: "250px" }}>

        {/* begin::header  */}
        <div className="header">

          {/* begin::header left  */}
          <ul className="navbar-nav">

            {/* begin::navigation-toggler  */}
            <li className="nav-item navigation-toggler">
              <a href="#" className="nav-link">
                <i data-feather="menu"></i>
              </a>
            </li>
            {/* end::navigation-toggler  */}

            {/* begin::header-logo  */}
            <li className="nav-item" id="header-logo">
              <a href="index.html">
                {/* <img className="logo" src="assets/media/image/logo.png" alt="logo" /> */}
                <img src="src\assets\media\image\logo.png" alt="logo" />
                <img className="logo-sm" src="assets/media/image/logo-sm.png" alt="small logo" />
                <img className="logo-dark" src="assets/media/image/logo-dark.png" alt="dark logo" />
              </a>
            </li>
            {/* end::header-logo  */}
          </ul>
          {/* end::header left  */}

          {/* begin::header-right  */}
          <div className="header-right">
            <ul className="navbar-nav">

              {/* begin::search-form  */}
              <li className="nav-item search-form">
                <div className="row">
                  <div className="col-md-6">
                    <form>
                      <div className="input-group">
                        <input type="text" className="form-control" placeholder="Search" />
                        <div className="input-group-append">
                          <button className="btn btn-default" type="button">
                            <i data-feather="search"></i>
                          </button>
                        </div>
                      </div>
                    </form>
                  </div>
                </div>
              </li>
              {/* end::search-form  */}

              {/* begin::header minimize/maximize  */}
              <li className="nav-item dropdown">
                <a href="#" className="nav-link" title="Fullscreen" data-toggle="fullscreen">
                  <i className="maximize" data-feather="maximize"></i>
                  <i className="minimize" data-feather="minimize"></i>
                </a>
              </li>
              {/* end::header minimize/maximize  */}

              {/* begin::header app list  */}
              <li className="nav-item dropdown">
                <a href="#" className="nav-link" title="Apps" data-toggle="dropdown">
                  <i data-feather="grid"></i>
                </a>
                <div className="dropdown-menu dropdown-menu-right dropdown-menu-big">
                  <div className="p-3">
                    <h6 className="text-uppercase font-size-11 mb-3">Web Apps</h6>
                    <div className="row row-xs">
                      <div className="col-6">
                        <a href="chat.html">
                          <div className="text-uppercase font-size-11 p-3 border-radius-1 border text-center mb-3">
                            <i className="text-success width-23 height-23"
                              data-feather="message-circle"></i>
                            <div className="mt-2">Chat</div>
                          </div>
                        </a>
                      </div>
                      <div className="col-6">
                        <a href="inbox.html">
                          <div className="text-uppercase font-size-11 p-3 border-radius-1 border text-center mb-3">
                            <i className="text-info width-23 height-23" data-feather="mail"></i>
                            <div className="mt-2">Mail</div>
                          </div>
                        </a>
                      </div>
                      <div className="col-6">
                        <a href="calendar.html">
                          <div className="text-uppercase font-size-11 p-3 border-radius-1 border text-center">
                            <i className="text-warning width-23 height-23" data-feather="calendar"></i>
                            <div className="mt-2">Calendar</div>
                          </div>
                        </a>
                      </div>
                      <div className="col-6">
                        <a href="file-manager.html">
                          <div className="text-uppercase font-size-11 p-3 border-radius-1 border text-center">
                            <i className="text-danger width-23 height-23" data-feather="file"></i>
                            <div className="mt-2">File Manager</div>
                          </div>
                        </a>
                      </div>
                    </div>
                  </div>
                </div>
              </li>
              {/* end::header app list  */}

              {/* begin::header messages dropdown  */}
              <li className="nav-item dropdown">
                <a href="#" className="nav-link nav-link-notify" title="Messages" data-toggle="dropdown">
                  <i data-feather="message-circle"></i>
                </a>
                <div className="dropdown-menu dropdown-menu-right dropdown-menu-big">
                  <div className="p-4 text-center" data-backround-image="https://via.placeholder.com/481X271">
                    <h6 className="mb-1">Messages</h6>
                    <small className="font-size-11 opacity-7">2 unread messages</small>
                  </div>
                  <div>
                    <ul className="list-group list-group-flush">
                      <li>
                        <a href="#" className="list-group-item d-flex hide-show-toggler">
                          <div>
                            <figure className="avatar avatar-sm m-r-15">
                              <img src="https://via.placeholder.com/128X128"
                                className="rounded-circle" alt="user" />
                            </figure>
                          </div>
                          <div className="flex-grow-1">
                            <p className="mb-0 line-height-20 d-flex justify-content-between">
                              Herbie Pallatina
                              <i title="Make unread" data-toggle="tooltip"
                                className="hide-show-toggler-item fa fa-circle-o font-size-11"></i>
                            </p>
                            <div className="small text-muted">
                              <span className="mr-2">02:30 PM</span>
                              <span>Have you madimage</span>
                            </div>
                          </div>
                        </a>
                      </li>
                      <li>
                        <a href="#"
                          className="list-group-item d-flex align-items-center hide-show-toggler">
                          <div>
                            <figure className="avatar avatar-sm m-r-15">
                              <img src="https://via.placeholder.com/128X128"
                                className="rounded-circle" alt="user" />
                            </figure>
                          </div>
                          <div className="flex-grow-1">
                            <p className="mb-0 line-height-20 d-flex justify-content-between">
                              Andrei Miners
                              <i title="Make unread" data-toggle="tooltip"
                                className="hide-show-toggler-item fa fa-circle-o font-size-11"></i>
                            </p>
                            <div className="small text-muted">
                              <span className="mr-2">08:36 PM</span>
                              <span>I have a meetinimage</span>
                            </div>
                          </div>
                        </a>
                      </li>
                      <li className="text-divider small pb-2 pl-3 pt-3">
                        <span>Old chats</span>
                      </li>
                      <li>
                        <a href="#"
                          className="list-group-item d-flex align-items-center hide-show-toggler">
                          <div>
                            <figure className="avatar avatar-sm m-r-15">
                              <img src="https://via.placeholder.com/128X128"
                                className="rounded-circle" alt="user" />
                            </figure>
                          </div>
                          <div className="flex-grow-1">
                            <p className="mb-0 line-height-20 d-flex justify-content-between">
                              Kevin added
                              <i title="Make unread" data-toggle="tooltip"
                                className="hide-show-toggler-item fa fa-check font-size-11"></i>
                            </p>
                            <div className="small text-muted">
                              <span className="mr-2">11:09 PM</span>
                              <span>Have you madimage</span>
                            </div>
                          </div>
                        </a>
                      </li>
                      <li>
                        <a href="#" className="list-group-item d-flex hide-show-toggler">
                          <div>
                            <figure className="avatar avatar-sm m-r-15">
                              <img src="https://via.placeholder.com/128X128"
                                className="rounded-circle" alt="user" />
                            </figure>
                          </div>
                          <div className="flex-grow-1">
                            <p className="mb-0 line-height-20 d-flex justify-content-between">
                              Eugenio Carnelley
                              <i title="Mark as read" data-toggle="tooltip"
                                className="hide-show-toggler-item fa fa-check font-size-11"></i>
                            </p>
                            <div className="small text-muted">
                              <span className="mr-2">Yesterday</span>
                              <span>I have a meetinimage</span>
                            </div>
                          </div>
                        </a>
                      </li>
                      <li>
                        <a href="#"
                          className="list-group-item d-flex align-items-center hide-show-toggler">
                          <div>
                            <figure className="avatar avatar-sm m-r-15">
                              <img src="https://via.placeholder.com/128X128"
                                className="rounded-circle" alt="user" />
                            </figure>
                          </div>
                          <div className="flex-grow-1">
                            <p className="mb-0 line-height-20 d-flex justify-content-between">
                              Neely Ferdinand
                              <i title="Make unread" data-toggle="tooltip"
                                className="hide-show-toggler-item fa fa-check font-size-11"></i>
                            </p>
                            <div className="small text-muted">
                              <span className="mr-2">Yesterday</span>
                              <span>I have a meetinimage</span>
                            </div>
                          </div>
                        </a>
                      </li>
                    </ul>
                  </div>
                  <div className="p-2 text-right">
                    <ul className="list-inline small">
                      <li className="list-inline-item">
                        <a href="#">Mark All Read</a>
                      </li>
                    </ul>
                  </div>
                </div>
              </li>
              {/* end::header messages dropdown  */}

              {/* begin::header notification dropdown  */}
              <li className="nav-item dropdown">
                <a href="#" className="nav-link nav-link-notify" title="Notifications" data-toggle="dropdown">
                  <i data-feather="bell"></i>
                </a>
                <div className="dropdown-menu dropdown-menu-right dropdown-menu-big">
                  <div className="p-4 text-center" data-backround-image="https://via.placeholder.com/481X271">
                    <h6 className="mb-1">Notifications</h6>
                    <small className="font-size-11 opacity-7">1 unread notifications</small>
                  </div>
                  <div>
                    <ul className="list-group list-group-flush">
                      <li>
                        <a href="#" className="list-group-item d-flex hide-show-toggler">
                          <div>
                            <figure className="avatar avatar-sm m-r-15">
                              <span className="avatar-title bg-success-bright text-success rounded-circle">
                                <i className="ti-user"></i>
                              </span>
                            </figure>
                          </div>
                          <div className="flex-grow-1">
                            <p className="mb-0 line-height-20 d-flex justify-content-between">
                              New customer registered
                              <i title="Make unread" data-toggle="tooltip"
                                className="hide-show-toggler-item fa fa-circle-o font-size-11"></i>
                            </p>
                            <span className="text-muted small">20 min ago</span>
                          </div>
                        </a>
                      </li>
                      <li className="text-divider small pb-2 pl-3 pt-3">
                        <span>Old notifications</span>
                      </li>
                      <li>
                        <a href="#" className="list-group-item d-flex hide-show-toggler">
                          <div>
                            <figure className="avatar avatar-sm m-r-15">
                              <span className="avatar-title bg-warning-bright text-warning rounded-circle">
                                <i className="ti-package"></i>
                              </span>
                            </figure>
                          </div>
                          <div className="flex-grow-1">
                            <p className="mb-0 line-height-20 d-flex justify-content-between">
                              New Order Recieved
                              <i title="Mark as read" data-toggle="tooltip"
                                className="hide-show-toggler-item fa fa-check font-size-11"></i>
                            </p>
                            <span className="text-muted small">45 sec ago</span>
                          </div>
                        </a>
                      </li>
                      <li>
                        <a href="#"
                          className="list-group-item d-flex align-items-center hide-show-toggler">
                          <div>
                            <figure className="avatar avatar-sm m-r-15">
                              <span className="avatar-title bg-danger-bright text-danger rounded-circle">
                                <i className="ti-server"></i>
                              </span>
                            </figure>
                          </div>
                          <div className="flex-grow-1">
                            <p className="mb-0 line-height-20 d-flex justify-content-between">
                              Server Limit Reached!
                              <i title="Make unread" data-toggle="tooltip"
                                className="hide-show-toggler-item fa fa-check font-size-11"></i>
                            </p>
                            <span className="text-muted small">55 sec ago</span>
                          </div>
                        </a>
                      </li>
                      <li>
                        <a href="#"
                          className="list-group-item d-flex align-items-center hide-show-toggler">
                          <div>
                            <figure className="avatar avatar-sm m-r-15">
                              <span className="avatar-title bg-info-bright text-info rounded-circle">
                                <i className="ti-layers"></i>
                              </span>
                            </figure>
                          </div>
                          <div className="flex-grow-1">
                            <p className="mb-0 line-height-20 d-flex justify-content-between">
                              Apps are ready for update
                              <i title="Make unread" data-toggle="tooltip"
                                className="hide-show-toggler-item fa fa-check font-size-11"></i>
                            </p>
                            <span className="text-muted small">Yesterday</span>
                          </div>
                        </a>
                      </li>
                    </ul>
                  </div>
                  <div className="p-2 text-right">
                    <ul className="list-inline small">
                      <li className="list-inline-item">
                        <a href="#">Mark All Read</a>
                      </li>
                    </ul>
                  </div>
                </div>
              </li>
              {/* end::header notification dropdown */}
            </ul>

            {/* begin::mobile header toggler  */}
            <ul className="navbar-nav d-flex align-items-center">
              <li className="nav-item header-toggler">
                <a href="#" className="nav-link">
                  <i data-feather="arrow-down"></i>
                </a>
              </li>
            </ul>
            {/* end::mobile header toggler  */}
          </div>
          {/* end::header-right  */}
        </div>
        {/* end::header */}

        {/* begin::main-content  */}
        <main className="main-content">

          <div className="container">

            <div className="row">
              <div className="col-md-4">

                <div className="card">
                  <div className="card-body text-center">
                    <figure className="avatar avatar-lg m-b-20">
                      <img src="https://via.placeholder.com/128X128" className="rounded-circle" alt="..." />
                    </figure>
                    <h5 className="mb-1">Nikos Pedlow</h5>
                    <p className="text-muted small">Web Developer</p>
                    <div className="row mb-2">
                      <div className="col-5 text-muted  text-left">First Name:</div>
                      <div className="col-6 text-left">Johnatan</div>
                    </div>
                    <div className="row mb-2">
                      <div className="col-5 text-muted text-left">Last Name:</div>
                      <div className="col-6 text-left">Due</div>
                    </div>
                    <div className="row mb-2">
                      <div className="col-5 text-muted text-left">Address:</div>
                      <div className="col-6 text-left">Pune, India</div>
                    </div>
                    <div className="row mb-2">
                      <div className="col-5 text-muted text-left">Phone:</div>
                      <div className="col-6 text-left">+91 9876543210</div>
                    </div>
                    <div className="row mb-2">
                      <div className="col-5 text-muted text-left">Email:</div>
                      <div className="col-6 text-left">admin@example.com</div>
                    </div>
                    <a href="#" className="btn btn-outline-primary">
                      <i data-feather="edit-2" className="mr-2"></i> Edit Profile
                    </a>
                  </div>
                  <hr className="m-0" />

                </div>

                <div className="card">
                  <div className="card-body">
                    <h6 className="card-title d-flex justify-content-between align-items-center">
                      Change Password
                    </h6>
                    <div className="form-group">
                      <label for="old_password">Old Password</label>
                      <span className="text-danger">*</span>
                      <input type="password" className="form-control" id="old_password" name="old_password"
                      />
                    </div>
                    <div className="form-group">
                      <label for="password">Password</label>
                      <span className="text-danger">*</span>
                      <input type="password" className="form-control" id="password" name="password"
                      />
                    </div>
                    <div className="form-group">
                      <label for="confirm_password">Confirm Password</label>
                      <span className="text-danger">*</span>
                      <input type="password" name="confirm_password" className="form-control" id="confirm_password"
                      />
                    </div>
                    <button className="btn btn-primary" type="submit">Change Password</button>
                  </div>
                </div>
              </div>
              <div className="col-md-8">

                <div className="card">
                  <div className="card-body">
                    <form className="needs-validation" novalidate>
                      <div className="form-row">
                        <div className="col-md-6 mb-3">
                          <label for="validationCustom01">First name</label>
                          <span className="text-danger">*</span>
                          <input type="text" className="form-control" id="validationCustom01" placeholder="First name" value="Mark" required />
                          <div className="valid-feedback">
                            Looks good!
                          </div>
                        </div>
                        <div className="col-md-6 mb-3">
                          <label for="validationCustom02">Last name</label>
                          <span className="text-danger">*</span>
                          <input type="text" className="form-control" id="validationCustom02" placeholder="Last name" value="Otto" required />
                          <div className="valid-feedback">
                            Looks good!
                          </div>
                        </div>
                        <div className="col-md-6 mb-3">
                          <label for="validationCustom03">Email</label>
                          <span className="text-danger">*</span>
                          <input type="email" className="form-control" id="validationCustom03" placeholder="admin@example.com" value="admin@example.com" required />

                        </div>
                        <div className="col-md-6 mb-3">
                          <label for="validationCustom04">Phone Number</label>
                          <span className="text-danger">*</span>
                          <input type="text" className="form-control" id="validationCustom04" placeholder="+91 9876543210" value="+91 9876543210" required />

                        </div>
                        <div className="form-group col-md-12">
                          <label for="exampleFormControlTextarea1">Address</label>
                          <span className="text-danger">*</span>
                          <textarea className="form-control" placeholder="Pune, India" id="exampleFormControlTextarea1" rows="5"></textarea>
                        </div>
                        <div className="form-group col-md-5">
                          <label for="exampleFormControlFile1">Image</label>
                          <input type="file" name="Image" className="form-control-file" id="exampleFormControlFile1" />
                        </div>
                        <div className="col-md-6"> <figure className="avatar avatar-sm m-r-15" style={{ width: "100px", height: "100px" }}>
                          <img src="https://via.placeholder.com/128X128"
                            className="rounded-circle" alt="user" width="100%" height="100%" />
                        </figure></div>

                      </div>


                      <button className="btn btn-primary float-right" type="submit">Submit</button>
                    </form>
                  </div>
                </div>

                {/*  <div className="card">
                        <div className="card-body">
                            <ul className="nav nav-pills flex-column flex-sm-row" id="myTab" role="tablist">
                                <li className="flex-sm-fill text-sm-center nav-item">
                                    <a className="nav-link active" id="home-tab" data-toggle="tab" href="#home"
                                       role="tab" aria-selected="true">Posts</a>
                                </li>
                                <li className="flex-sm-fill text-sm-center nav-item">
                                    <a className="nav-link" id="timeline-tab" data-toggle="tab" href="#timeline"
                                       role="tab" aria-selected="true">Timeline</a>
                                </li>
                                <li className="flex-sm-fill text-sm-center nav-item">
                                    <a className="nav-link" id="connections-tab1" data-toggle="tab" href="#connections"
                                       role="tab"
                                       aria-selected="false">
                                        Connections <span className="badge badge-light m-l-5">6</span>
                                    </a>
                                </li>
                                <li className="flex-sm-fill text-sm-center nav-item">
                                    <a className="nav-link" id="earnings-tab" data-toggle="tab" href="#earnings" role="tab"
                                       aria-selected="false">Earnings</a>
                                </li>
                            </ul>
                        </div>
                    </div>  */}



              </div>
            </div>

          </div>

        </main>
        {/* end::main-content  */}

        {/* begin::footer  */}
        <footer>
          <div className="container">
            <div>© 2019 Protable v1.0.0 Made by <a href="http://laborasyon.com">Laborasyon</a></div>
            <div>
              <nav className="nav">
                <a href="https://themeforest.net/licenses/standard" className="nav-link">Licenses</a>
                <a href="#" className="nav-link">Change Log</a>
                <a href="#" className="nav-link">Get Help</a>
              </nav>
            </div>
          </div>
        </footer>
        {/* end::footer  */}

      </div>
      {/* end::main  */}

    </>
  )
}

export default Profile