import React,{useState} from 'react'
import ResetPassword from './ResetPassword';
import { useNavigate } from "react-router-dom";

function Login() {
  var navigate = useNavigate()
  const handleClick = () => {
    navigate("/reset");
  };
  
  return (
    <>
    <div className="form-wrapper"  >
        {/* logo  */}
        <div id="logo">
          <h2>PropTech</h2>
        </div>
        {/* ./ logo  */}
        <h5>Log In</h5>
        {/* <form  */}
        <form  >
          <div className="form-group">
            <input type="text" className="form-control" placeholder="Username or email" required autofocus />
          </div>
          <div className="form-group">
            <input type="password" className="form-control" placeholder="Password" required />
          </div>
          <div className="form-group d-flex justify-content-between">
            <div className="custom-control custom-checkbox">
              {/* <input type="checkbox" className="custom-control-input" checked="" id="customCheck1" /> */}
              <input  type="checkbox" id="exampleCheckbox"  className="custom-control-input"  />
              <label className="custom-control-label" for="customCheck1">Remember me</label>
            </div>
            <a href="recover-password.html">Reset password</a>
          </div>
          <button className="btn btn-primary btn-block" onClick={()=>handleClick()}>Log In</button>
          <hr/>
          <p className="text-muted">Don't have an account?</p>
          <a href="./registration.js"/>
          <a href="./register.html" className="btn btn-outline-light btn-sm"style={{ display: "flex", justifyContent: "center", alignItems: 'center' }}>Register now!</a>
        </form>
        {/* ./ form */}
      </div>
    </>
  )
}

export default Login