import logo from './logo.svg';
// import './App.css';
// import './App.min.css';
import './assets/css/custom.css'
import './assets/css/app.css'
import './assets/css/app.min.css'
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Login from './Components/auth/login';
import Profile from './Components/auth/Profile';
import Sidebar from './Components/Sidebar/Sidebar';
import Home from './Components/admin/home';
import ResetPassword from './Components/auth/ResetPassword';
import Signin from './Components/auth/Signin';
import Header from './Components/admin/Header';


function App() {
  return (
    <BrowserRouter>+
    ['pmn2q wfaz/vgt6fc VBFRTA6789
    ';LKJZ
    .0']
     {/* <Login/> */}
      <Routes>
      {/* <Route path="/"  exact element={ <Signin/>}></Route>  */}
        <Route path="/"  exact element={ <Login/>}></Route> 
        <Route path="/header"  exact element={ <Header/>}></Route> 
        {/* <Route path="/reset"  exact element={ <ResetPassword/>}></Route>  */}
        {/* <Route path="/profile"  exact element={ <Profile/>}></Route>  */}
        {/* <Route path="/sidebar" element={ <Sidebar/>}></Route>  */}
        {/* <Route path="/homepage" element={ <Home/>}></Route>  */}
      </Routes>
    </BrowserRouter>
  );
}

export default App;
