import React from 'react';
const AddBuyer = () => {
    return (
        <div class="rtl">
           {/* <!-- begin::main --> */}
            <div id="main" >
                {/* <!-- begin::main-content --> */}
                <div class="main-content">

                    <div class="container">

                        {/* <!-- begin::page-header --> */}
                        <div class="page-header">
                            <h4>Add Buyer</h4>
                            <nav aria-label="breadcrumb">
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item">
                                        <a href="#">Home</a>
                                    </li>
                                    <li class="breadcrumb-item">
                                        <a href="#">User Management Screen</a>
                                    </li>
                                    <li class="breadcrumb-item">
                                        <a href="#">Buyers</a>
                                    </li>
                                    <li class="breadcrumb-item active" aria-current="page">Add Buyer</li>
                                </ol>
                            </nav>
                        </div>
                        {/* <!-- end::page-header --> */}

                        <div class="row">
                            <div class="col-md-12">

                                <div class="card">
                                    <div class="card-body">

                                        <form class="needs-validation" novalidate="">
                                            <div class="form-row">
                                                <div class="col-md-4 mb-3">
                                                    <label for="validationCustom01">Full Name</label>
                                                    <input type="text" class="form-control" id="validationCustom01" placeholder="enter your full name"
                                                        required="" />
                                                    <div class="valid-feedback">
                                                        Looks good!
                                                    </div>
                                                </div>
                                                <div class="col-md-4 mb-3">
                                                    <label for="validationCustom02">Contact Number</label>
                                                    <input type="text" data-input-mask="phone" class="form-control" id="validationCustom02" placeholder="9087654321" required="" />
                                                    <div class="valid-feedback">
                                                        Looks good!
                                                    </div>
                                                </div>
                                                <div class="col-md-4 mb-3">
                                                    <label for="validationCustom03">Budget</label>
                                                    <input type="text" class="form-control" id="validationCustom03" placeholder="enter your Budget" required="" />
                                                    <div class="valid-feedback">
                                                        Looks good!
                                                    </div>
                                                </div>

                                            </div>
                                            <div class="form-row">
                                                <div class="col-md-6 mb-3">
                                                    <label for="validationCustom04">Location Preferences</label>
                                                    <input type="text" class="form-control" id="validationCustom04" placeholder=""
                                                        required="" />
                                                    <div class="invalid-feedback">
                                                        Please provide a valid location.
                                                    </div>
                                                </div>
                                                <div class="col-md-3 mb-3">
                                                    <label for="validationCustom04">Property Type</label>
                                                    <select class="select2-example">
                                                        <option>Select</option>
                                                        <option value="House">House</option>
                                                        <option value="Apartment">Apartment</option>
                                                        <option value="Land">Land</option>
                                                    </select>
                                                    <div class="invalid-feedback">

                                                    </div>
                                                </div>
                                                <div class="col-md-3 mb-3">
                                                    <label for="validationCustom06">Preferred Square Footage</label>
                                                    <input type="text" class="form-control" id="validationCustom06" placeholder="" required="" />
                                                    <div class="invalid-feedback">

                                                    </div>
                                                </div>
                                                <div class="col-md-6 mb-3">
                                                    <label for="validationCustom05">Amenities</label>
                                                    <textarea class="form-control" id="validationCustom05" rows="3"></textarea>

                                                    {/* <!-- <input type="text" class="form-control" id="validationCustom05" placeholder="enter amenities"required=""/> --> */}
                                                    <div class="invalid-feedback">

                                                    </div>
                                                </div>
                                                <div class="col-md-6 mb-3">
                                                    <label for="validationCustom07">Preferred Neighborhood Features</label>
                                                    <textarea class="form-control" id="validationCustom07" rows="3"></textarea>
                                                    <div class="invalid-feedback">

                                                    </div>
                                                </div>
                                                <div class="col-md-3 mb-3">
                                                    <label for="validationCustom08">Financing</label>
                                                    <select class="select2-example">
                                                        <option value="Cash">Cash</option>
                                                        <option value=" Mortgage"> Mortgage</option>
                                                        <option value="Other Options">Other Options</option>
                                                    </select>
                                                    <div class="invalid-feedback">

                                                    </div>
                                                </div>
                                                <div class="col-md-6 mb-3">
                                                    <label for="validationCustom09">Additional Comments/Notes</label>
                                                    <textarea class="form-control" id="validationCustom09" rows="3"></textarea>
                                                    <div class="invalid-feedback">

                                                    </div>
                                                </div>
                                            </div>
                                            <div class="form-group">
                                                <div class="form-check">
                                                    <input class="form-check-input" type="checkbox" value="" id="invalidCheck" required="" />
                                                    <label class="form-check-label" for="invalidCheck">
                                                        Agree to terms and conditions
                                                    </label>
                                                    <div class="invalid-feedback">
                                                        You must agree before submitting.
                                                    </div>
                                                </div>
                                            </div>
                                            <button class="btn btn-primary" type="submit">Submit </button>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>

                </div>
                {/* <!-- end::main-content --> */}
            </div>
            {/* <!-- end::main --> */}

            {/* <!-- Plugin scripts --> */}
            <script src="vendors/bundle.js"></script>

            {/* // <!-- Chartjs --> */}
            <script src="vendors/charts/chartjs/chart.min.js"></script>

            {/* <!-- Apex chart --> */}
            <script src="vendors/charts/apex/apexcharts.min.js"></script>

            {/* <!-- Circle progress --> */}
            <script src="vendors/circle-progress/circle-progress.min.js"></script>

            {/* <!-- Peity --> */}
            <script src="vendors/charts/peity/jquery.peity.min.js"></script>
            <script src="assets/js/examples/charts/peity.js"></script>

            {/* <!-- Datepicker --> */}
            <script src="vendors/datepicker/daterangepicker.js"></script>

            {/* <!-- Slick --> */}
            <script src="vendors/slick/slick.min.js"></script>

            {/* <!-- Vamp --> */}
            <script src="vendors/vmap/jquery.vmap.min.js"></script>
            <script src="vendors/vmap/maps/jquery.vmap.usa.js"></script>
            <script src="assets/js/examples/vmap.js"></script>

            {/* <!-- Dashboard scripts --> */}
            <script src="assets/js/examples/dashboard.js"></script>
            <div class="colors">
                {/* <!-- To use theme colors with Javascript --> */}
                <div class="bg-primary"></div>
                <div class="bg-primary-bright"></div>
                <div class="bg-secondary"></div>
                <div class="bg-secondary-bright"></div>
                <div class="bg-info"></div>
                <div class="bg-info-bright"></div>
                <div class="bg-success"></div>
                <div class="bg-success-bright"></div>
                <div class="bg-danger"></div>
                <div class="bg-danger-bright"></div>
                <div class="bg-warning"></div>
                <div class="bg-warning-bright"></div>
            </div>

            {/* <!-- Javascript --> */}
            <script src="vendors/select2/js/select2.min.js"></script>

            {/* <!-- App scripts --> */}
            <script src="assets/js/app.min.js"></script>

            <script src="vendors/input-mask/jquery.mask.js"></script>

            {/* <script>
                $('[data-input-mask="phone"]').mask('0000000000');

                $('.select2-example').select2({
                    placeholder = 'Select'
                });
            </script> */}
        </div>
    );
}

export default AddBuyer;
