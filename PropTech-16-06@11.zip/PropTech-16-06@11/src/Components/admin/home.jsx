import React from 'react'
import Login from '../auth/login'

function Home() {
  return (
    <div>
        
        {/* <!-- begin::main --> */}
    <div id="main">

        {/* <!-- begin::header --> */}
        <div className="header">

            {/* <!-- begin::header left --> */}
            <ul className="navbar-nav">

                {/* <!-- begin::navigation-toggler --> */}
                <li className="nav-item navigation-toggler">
                    <a href="#" className="nav-link">
                        <i data-feather="menu"></i>
                    </a>
                </li>
                {/* <!-- end::navigation-toggler --> */}

                {/* <!-- begin::header-logo --> */}
                <li className="nav-item" id="header-logo">
                    <a href="index.html">
                        <img className="logo" src="assets/media/image/logo.png" alt="logo"/>
                        <img className="logo-sm" src="assets/media/image/logo-sm.png" alt="small logo"/>
                        <img className="logo-dark" src="assets/media/image/logo-dark.png" alt="dark logo"/>
                    </a>
                </li>
                {/* <!-- end::header-logo --> */}
            </ul>
            {/* <!-- end::header left --> */}

            {/* <!-- begin::header-right --> */}
            <div className="header-right">
                <ul className="navbar-nav">

                    {/* <!-- begin::search-form --> */}
                    <li className="nav-item search-form">
                        <div className="row">
                            <div className="col-md-6">
                                <form>
                                    <div className="input-group">
                                        <input type="text" className="form-control" placeholder="Search"/>
                                        <div className="input-group-append">
                                            <button className="btn btn-default" type="button">
                                                <i data-feather="search"></i>
                                            </button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </li>
                    {/* <!-- end::search-form --> */}

                    {/* <!-- begin::header minimize/maximize --> */}
                    <li className="nav-item dropdown">
                        <a href="#" className="nav-link" title="Fullscreen" data-toggle="fullscreen">
                            <i className="maximize" data-feather="maximize"></i>
                            <i className="minimize" data-feather="minimize"></i>
                        </a>
                    </li>
                    {/* <!-- end::header minimize/maximize --> */}

                    {/* <!-- begin::header app list --> */}
                    <li className="nav-item dropdown">
                        <a href="#" className="nav-link" title="Apps" data-toggle="dropdown">
                            <i data-feather="grid"></i>
                        </a>
                        <div className="dropdown-menu dropdown-menu-right dropdown-menu-big">
                            <div className="p-3">
                                <h6 className="text-uppercase font-size-11 mb-3">Web Apps</h6>
                                <div className="row row-xs">
                                    <div className="col-6">
                                        <a href="chat.html">
                                            <div
                                                className="text-uppercase font-size-11 p-3 border-radius-1 border text-center mb-3">
                                                <i className="text-success width-23 height-23"
                                                    data-feather="message-circle"></i>
                                                <div className="mt-2">Chat</div>
                                            </div>
                                        </a>
                                    </div>
                                    <div className="col-6">
                                        <a href="inbox.html">
                                            <div
                                                className="text-uppercase font-size-11 p-3 border-radius-1 border text-center mb-3">
                                                <i className="text-info width-23 height-23" data-feather="mail"></i>
                                                <div className="mt-2">Mail</div>
                                            </div>
                                        </a>
                                    </div>
                                    <div className="col-6">
                                        <a href="calendar.html">
                                            <div
                                                className="text-uppercase font-size-11 p-3 border-radius-1 border text-center">
                                                <i className="text-warning width-23 height-23" data-feather="calendar"></i>
                                                <div className="mt-2">Calendar</div>
                                            </div>
                                        </a>
                                    </div>
                                    <div className="col-6">
                                        <a href="file-manager.html">
                                            <div
                                                className="text-uppercase font-size-11 p-3 border-radius-1 border text-center">
                                                <i className="text-danger width-23 height-23" data-feather="file"></i>
                                                <div className="mt-2">File Manager</div>
                                            </div>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </li>
                    {/* <!-- end::header app list --> */}

                    {/* <!-- begin::header messages dropdown --> */}
                    <li className="nav-item dropdown">
                        <a href="#" className="nav-link nav-link-notify" title="Messages" data-toggle="dropdown">
                            <i data-feather="message-circle"></i>
                        </a>
                        <div className="dropdown-menu dropdown-menu-right dropdown-menu-big">
                            <div className="p-4 text-center" data-backround-image="https://via.placeholder.com/481X271">
                                <h6 className="mb-1">Messages</h6>
                                <small className="font-size-11 opacity-7">2 unread messages</small>
                            </div>
                            <div>
                                <ul className="list-group list-group-flush">
                                    <li>
                                        <a href="#" className="list-group-item d-flex hide-show-toggler">
                                            <div>
                                                <figure className="avatar avatar-sm m-r-15">
                                                    <img src="https://via.placeholder.com/128X128"
                                                        className="rounded-circle" alt="user"/>
                                                </figure>
                                            </div>
                                            <div className="flex-grow-1">
                                                <p className="mb-0 line-height-20 d-flex justify-content-between">
                                                    Herbie Pallatina
                                                    <i title="Make unread" data-toggle="tooltip"
                                                        className="hide-show-toggler-item fa fa-circle-o font-size-11"></i>
                                                </p>
                                                <div className="small text-muted">
                                                    <span className="mr-2">02:30 PM</span>
                                                    <span>Have you madimage</span>
                                                </div>
                                            </div>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="#" className="list-group-item d-flex align-items-center hide-show-toggler">
                                            <div>
                                                <figure className="avatar avatar-sm m-r-15">
                                                    <img src="https://via.placeholder.com/128X128"
                                                        className="rounded-circle" alt="user"/>
                                                </figure>
                                            </div>
                                            <div className="flex-grow-1">
                                                <p className="mb-0 line-height-20 d-flex justify-content-between">
                                                    Andrei Miners
                                                    <i title="Make unread" data-toggle="tooltip"
                                                        className="hide-show-toggler-item fa fa-circle-o font-size-11"></i>
                                                </p>
                                                <div className="small text-muted">
                                                    <span className="mr-2">08:36 PM</span>
                                                    <span>I have a meetinimage</span>
                                                </div>
                                            </div>
                                        </a>
                                    </li>
                                    <li className="text-divider small pb-2 pl-3 pt-3">
                                        <span>Old chats</span>
                                    </li>
                                    <li>
                                        <a href="#" className="list-group-item d-flex align-items-center hide-show-toggler">
                                            <div>
                                                <figure className="avatar avatar-sm m-r-15">
                                                    <img src="https://via.placeholder.com/128X128"
                                                        className="rounded-circle" alt="user"/>
                                                </figure>
                                            </div>
                                            <div className="flex-grow-1">
                                                <p className="mb-0 line-height-20 d-flex justify-content-between">
                                                    Kevin added
                                                    <i title="Make unread" data-toggle="tooltip"
                                                        className="hide-show-toggler-item fa fa-check font-size-11"></i>
                                                </p>
                                                <div className="small text-muted">
                                                    <span className="mr-2">11:09 PM</span>
                                                    <span>Have you madimage</span>
                                                </div>
                                            </div>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="#" className="list-group-item d-flex hide-show-toggler">
                                            <div>
                                                <figure className="avatar avatar-sm m-r-15">
                                                    <img src="https://via.placeholder.com/128X128"
                                                        className="rounded-circle" alt="user"/>
                                                </figure>
                                            </div>
                                            <div className="flex-grow-1">
                                                <p className="mb-0 line-height-20 d-flex justify-content-between">
                                                    Eugenio Carnelley
                                                    <i title="Mark as read" data-toggle="tooltip"
                                                        className="hide-show-toggler-item fa fa-check font-size-11"></i>
                                                </p>
                                                <div className="small text-muted">
                                                    <span className="mr-2">Yesterday</span>
                                                    <span>I have a meetinimage</span>
                                                </div>
                                            </div>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="#" className="list-group-item d-flex align-items-center hide-show-toggler">
                                            <div>
                                                <figure className="avatar avatar-sm m-r-15">
                                                    <img src="https://via.placeholder.com/128X128"
                                                        className="rounded-circle" alt="user"/>
                                                </figure>
                                            </div>
                                            <div className="flex-grow-1">
                                                <p className="mb-0 line-height-20 d-flex justify-content-between">
                                                    Neely Ferdinand
                                                    <i title="Make unread" data-toggle="tooltip"
                                                        className="hide-show-toggler-item fa fa-check font-size-11"></i>
                                                </p>
                                                <div className="small text-muted">
                                                    <span className="mr-2">Yesterday</span>
                                                    <span>I have a meetinimage</span>
                                                </div>
                                            </div>
                                        </a>
                                    </li>
                                </ul>
                            </div>
                            <div className="p-2 text-right">
                                <ul className="list-inline small">
                                    <li className="list-inline-item">
                                        <a href="#">Mark All Read</a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </li>
                    {/* <!-- end::header messages dropdown --> */}

                    {/* <!-- begin::header notification dropdown --> */}
                    <li className="nav-item dropdown">
                        <a href="#" className="nav-link nav-link-notify" title="Notifications" data-toggle="dropdown">
                            <i data-feather="bell"></i>
                        </a>
                        <div className="dropdown-menu dropdown-menu-right dropdown-menu-big">
                            <div className="p-4 text-center" data-backround-image="https://via.placeholder.com/481X271">
                                <h6 className="mb-1">Notifications</h6>
                                <small className="font-size-11 opacity-7">1 unread notifications</small>
                            </div>
                            <div>
                                <ul className="list-group list-group-flush">
                                    <li>
                                        <a href="#" className="list-group-item d-flex hide-show-toggler">
                                            <div>
                                                <figure className="avatar avatar-sm m-r-15">
                                                    <span
                                                        className="avatar-title bg-success-bright text-success rounded-circle">
                                                        <i className="ti-user"></i>
                                                    </span>
                                                </figure>
                                            </div>
                                            <div className="flex-grow-1">
                                                <p className="mb-0 line-height-20 d-flex justify-content-between">
                                                    New customer registered
                                                    <i title="Make unread" data-toggle="tooltip"
                                                        className="hide-show-toggler-item fa fa-circle-o font-size-11"></i>
                                                </p>
                                                <span className="text-muted small">20 min ago</span>
                                            </div>
                                        </a>
                                    </li>
                                    <li className="text-divider small pb-2 pl-3 pt-3">
                                        <span>Old notifications</span>
                                    </li>
                                    <li>
                                        <a href="#" className="list-group-item d-flex hide-show-toggler">
                                            <div>
                                                <figure className="avatar avatar-sm m-r-15">
                                                    <span
                                                        className="avatar-title bg-warning-bright text-warning rounded-circle">
                                                        <i className="ti-package"></i>
                                                    </span>
                                                </figure>
                                            </div>
                                            <div className="flex-grow-1">
                                                <p className="mb-0 line-height-20 d-flex justify-content-between">
                                                    New Order Recieved
                                                    <i title="Mark as read" data-toggle="tooltip"
                                                        className="hide-show-toggler-item fa fa-check font-size-11"></i>
                                                </p>
                                                <span className="text-muted small">45 sec ago</span>
                                            </div>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="#" className="list-group-item d-flex align-items-center hide-show-toggler">
                                            <div>
                                                <figure className="avatar avatar-sm m-r-15">
                                                    <span
                                                        className="avatar-title bg-danger-bright text-danger rounded-circle">
                                                        <i className="ti-server"></i>
                                                    </span>
                                                </figure>
                                            </div>
                                            <div className="flex-grow-1">
                                                <p className="mb-0 line-height-20 d-flex justify-content-between">
                                                    Server Limit Reached!
                                                    <i title="Make unread" data-toggle="tooltip"
                                                        className="hide-show-toggler-item fa fa-check font-size-11"></i>
                                                </p>
                                                <span className="text-muted small">55 sec ago</span>
                                            </div>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="#" className="list-group-item d-flex align-items-center hide-show-toggler">
                                            <div>
                                                <figure className="avatar avatar-sm m-r-15">
                                                    <span className="avatar-title bg-info-bright text-info rounded-circle">
                                                        <i className="ti-layers"></i>
                                                    </span>
                                                </figure>
                                            </div>
                                            <div className="flex-grow-1">
                                                <p className="mb-0 line-height-20 d-flex justify-content-between">
                                                    Apps are ready for update
                                                    <i title="Make unread" data-toggle="tooltip"
                                                        className="hide-show-toggler-item fa fa-check font-size-11"></i>
                                                </p>
                                                <span className="text-muted small">Yesterday</span>
                                            </div>
                                        </a>
                                    </li>
                                </ul>
                            </div>
                            <div className="p-2 text-right">
                                <ul className="list-inline small">
                                    <li className="list-inline-item">
                                        <a href="#">Mark All Read</a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </li>
                    {/* <!-- end::header notification dropdown --> */}
                </ul>

                {/* <!-- begin::mobile header toggler --> */}
                <ul className="navbar-nav d-flex align-items-center">
                    <li className="nav-item header-toggler">
                        <a href="#" className="nav-link">
                            <i data-feather="arrow-down"></i>
                        </a>
                    </li>
                </ul>
                {/* <!-- end::mobile header toggler --> */}
            </div>
            {/* <!-- end::header-right --> */}
        </div>
        {/* <!-- end::header --> */}

        {/* <!-- begin::main-content --> */}
        <main className="main-content">

            <div className="container">

                {/* <!-- begin::page-header --> */}
                <div className="page-header">
                    <h4>Navs</h4>
                    <nav aria-label="breadcrumb">
                        <ol className="breadcrumb">
                            <li className="breadcrumb-item">
                                <a href="#">Home</a>
                            </li>
                            <li className="breadcrumb-item">
                                <a href="#">Components</a>
                            </li>
                            <li className="breadcrumb-item active" aria-current="page">Navs</li>
                        </ol>
                    </nav>
                </div>
                {/* <!-- end::page-header --> */}

                 <div className="row">
                    <div className="col-md-12">

                        <div className="card">
                            <div className="card-body">
                                <h6 className="card-title">Base nav</h6>
                                <ul className="nav">
                                    <li className="nav-item">
                                        <a className="nav-link active" href="#">Active</a>
                                    </li>
                                    <li className="nav-item">
                                        <a className="nav-link" href="#">Link</a>
                                    </li>
                                    <li className="nav-item">
                                        <a className="nav-link" href="#">Link</a>
                                    </li>
                                    <li className="nav-item">
                                        <a className="nav-link disabled" href="#" tabindex="-1"
                                            aria-disabled="true">Disabled</a>
                                    </li>
                                </ul>

                                <div data-label="CODE EXAMPLE" className="demo-code-preview">
                                    <pre><code className="language-html">&lt;ul className="nav"&gt;
  &lt;li className="nav-item"&gt;
    &lt;a className="nav-link active" href="#"&gt;Active&lt;/a&gt;
  &lt;/li&gt;
  &lt;li className="nav-item"&gt;
    &lt;a className="nav-link" href="#"&gt;Link&lt;/a&gt;
  &lt;/li&gt;
  &lt;li className="nav-item"&gt;
    &lt;a className="nav-link" href="#"&gt;Link&lt;/a&gt;
  &lt;/li&gt;
  &lt;li className="nav-item"&gt;
    &lt;a className="nav-link disabled" href="#" tabindex="-1" aria-disabled="true"&gt;Disabled&lt;/a&gt;
  &lt;/li&gt;
&lt;/ul&gt;</code></pre>
                                </div>
                            </div>
                        </div>

                        <div className="card">
                            <div className="card-body">
                                <h6 className="card-title">Horizontal alignment</h6>
                                <ul className="nav justify-content-center">
                                    <li className="nav-item">
                                        <a className="nav-link active" href="#">Active</a>
                                    </li>
                                    <li className="nav-item">
                                        <a className="nav-link" href="#">Link</a>
                                    </li>
                                    <li className="nav-item">
                                        <a className="nav-link" href="#">Link</a>
                                    </li>
                                    <li className="nav-item">
                                        <a className="nav-link disabled" href="#" tabindex="-1"
                                            aria-disabled="true">Disabled</a>
                                    </li>
                                </ul>
                                <ul className="nav justify-content-end">
                                    <li className="nav-item">
                                        <a className="nav-link active" href="#">Active</a>
                                    </li>
                                    <li className="nav-item">
                                        <a className="nav-link" href="#">Link</a>
                                    </li>
                                    <li className="nav-item">
                                        <a className="nav-link" href="#">Link</a>
                                    </li>
                                    <li className="nav-item">
                                        <a className="nav-link disabled" href="#" tabindex="-1"
                                            aria-disabled="true">Disabled</a>
                                    </li>
                                </ul>

                                <div data-label="CODE EXAMPLE" className="demo-code-preview">
                                    <pre><code className="language-html">&lt;ul className="nav justify-content-center"&gt;
  &lt;li className="nav-item"&gt;
    &lt;a className="nav-link active" href="#"&gt;Active&lt;/a&gt;
  &lt;/li&gt;
  &lt;li className="nav-item"&gt;
    &lt;a className="nav-link" href="#"&gt;Link&lt;/a&gt;
  &lt;/li&gt;
  &lt;li className="nav-item"&gt;
    &lt;a className="nav-link" href="#"&gt;Link&lt;/a&gt;
  &lt;/li&gt;
  &lt;li className="nav-item"&gt;
    &lt;a className="nav-link disabled" href="#" tabindex="-1" aria-disabled="true"&gt;Disabled&lt;/a&gt;
  &lt;/li&gt;
&lt;/ul&gt;

&lt;ul className="nav justify-content-end"&gt;
  &lt;li className="nav-item"&gt;
    &lt;a className="nav-link active" href="#"&gt;Active&lt;/a&gt;
  &lt;/li&gt;
  &lt;li className="nav-item"&gt;
    &lt;a className="nav-link" href="#"&gt;Link&lt;/a&gt;
  &lt;/li&gt;
  &lt;li className="nav-item"&gt;
    &lt;a className="nav-link" href="#"&gt;Link&lt;/a&gt;
  &lt;/li&gt;
  &lt;li className="nav-item"&gt;
    &lt;a className="nav-link disabled" href="#" tabindex="-1" aria-disabled="true"&gt;Disabled&lt;/a&gt;
  &lt;/li&gt;
&lt;/ul&gt;</code></pre>
                                </div>
                            </div>
                        </div>

                        <div className="card">
                            <div className="card-body">
                                <h6 className="card-title">Vertical</h6>
                                <ul className="nav flex-column">
                                    <li className="nav-item">
                                        <a className="nav-link active" href="#">Active</a>
                                    </li>
                                    <li className="nav-item">
                                        <a className="nav-link" href="#">Link</a>
                                    </li>
                                    <li className="nav-item">
                                        <a className="nav-link" href="#">Link</a>
                                    </li>
                                    <li className="nav-item">
                                        <a className="nav-link disabled" href="#" tabindex="-1"
                                            aria-disabled="true">Disabled</a>
                                    </li>
                                </ul>

                                <div data-label="CODE EXAMPLE" className="demo-code-preview">
                                    <pre><code className="language-html">&lt;ul className="nav flex-column"&gt;
  &lt;li className="nav-item"&gt;
    &lt;a className="nav-link active" href="#"&gt;Active&lt;/a&gt;
  &lt;/li&gt;
  &lt;li className="nav-item"&gt;
    &lt;a className="nav-link" href="#"&gt;Link&lt;/a&gt;
  &lt;/li&gt;
  &lt;li className="nav-item"&gt;
    &lt;a className="nav-link" href="#"&gt;Link&lt;/a&gt;
  &lt;/li&gt;
  &lt;li className="nav-item"&gt;
    &lt;a className="nav-link disabled" href="#" tabindex="-1" aria-disabled="true"&gt;Disabled&lt;/a&gt;
  &lt;/li&gt;
&lt;/ul&gt;</code></pre>
                                </div>
                            </div>
                        </div>

                        <div className="card">
                            <div className="card-body">
                                <h6 className="card-title">Tabs</h6>
                                <ul className="nav nav-tabs">
                                    <li className="nav-item">
                                        <a className="nav-link active" href="#">Active</a>
                                    </li>
                                    <li className="nav-item">
                                        <a className="nav-link" href="#">Link</a>
                                    </li>
                                    <li className="nav-item">
                                        <a className="nav-link" href="#">Link</a>
                                    </li>
                                    <li className="nav-item">
                                        <a className="nav-link disabled" href="#" tabindex="-1"
                                            aria-disabled="true">Disabled</a>
                                    </li>
                                </ul>

                                <div data-label="CODE EXAMPLE" className="demo-code-preview">
                                    <pre><code className="language-html">&lt;ul className="nav nav-tabs"&gt;
  &lt;li className="nav-item"&gt;
    &lt;a className="nav-link active" href="#"&gt;Active&lt;/a&gt;
  &lt;/li&gt;
  &lt;li className="nav-item"&gt;
    &lt;a className="nav-link" href="#"&gt;Link&lt;/a&gt;
  &lt;/li&gt;
  &lt;li className="nav-item"&gt;
    &lt;a className="nav-link" href="#"&gt;Link&lt;/a&gt;
  &lt;/li&gt;
  &lt;li className="nav-item"&gt;
    &lt;a className="nav-link disabled" href="#" tabindex="-1" aria-disabled="true"&gt;Disabled&lt;/a&gt;
  &lt;/li&gt;
&lt;/ul&gt;</code></pre>
                                </div>
                            </div>
                        </div>

                        <div className="card">
                            <div className="card-body">
                                <h6 className="card-title">Pills</h6>
                                <ul className="nav nav-pills">
                                    <li className="nav-item">
                                        <a className="nav-link active" href="#">Active</a>
                                    </li>
                                    <li className="nav-item">
                                        <a className="nav-link" href="#">Link</a>
                                    </li>
                                    <li className="nav-item">
                                        <a className="nav-link" href="#">Link</a>
                                    </li>
                                    <li className="nav-item">
                                        <a className="nav-link disabled" href="#" tabindex="-1"
                                            aria-disabled="true">Disabled</a>
                                    </li>
                                </ul>

                                <div data-label="CODE EXAMPLE" className="demo-code-preview">
                                    <pre><code className="language-html">&lt;ul className="nav nav-pills"&gt;
  &lt;li className="nav-item"&gt;
    &lt;a className="nav-link active" href="#"&gt;Active&lt;/a&gt;
  &lt;/li&gt;
  &lt;li className="nav-item"&gt;
    &lt;a className="nav-link" href="#"&gt;Link&lt;/a&gt;
  &lt;/li&gt;
  &lt;li className="nav-item"&gt;
    &lt;a className="nav-link" href="#"&gt;Link&lt;/a&gt;
  &lt;/li&gt;
  &lt;li className="nav-item"&gt;
    &lt;a className="nav-link disabled" href="#" tabindex="-1" aria-disabled="true"&gt;Disabled&lt;/a&gt;
  &lt;/li&gt;
&lt;/ul&gt;</code></pre>
                                </div>
                            </div>
                        </div>

                        <div className="card">
                            <div className="card-body">
                                <h6 className="card-title">Fill and justify</h6>
                                <ul className="nav nav-pills nav-fill">
                                    <li className="nav-item">
                                        <a className="nav-link active" href="#">Active</a>
                                    </li>
                                    <li className="nav-item">
                                        <a className="nav-link" href="#">Longer nav link</a>
                                    </li>
                                    <li className="nav-item">
                                        <a className="nav-link" href="#">Link</a>
                                    </li>
                                    <li className="nav-item">
                                        <a className="nav-link disabled" href="#" tabindex="-1"
                                            aria-disabled="true">Disabled</a>
                                    </li>
                                </ul>

                                <div data-label="CODE EXAMPLE" className="demo-code-preview">
                                    <pre><code className="language-html">&lt;ul className="nav nav-pills nav-fill"&gt;
  &lt;li className="nav-item"&gt;
    &lt;a className="nav-link active" href="#"&gt;Active&lt;/a&gt;
  &lt;/li&gt;
  &lt;li className="nav-item"&gt;
    &lt;a className="nav-link" href="#"&gt;Longer nav link&lt;/a&gt;
  &lt;/li&gt;
  &lt;li className="nav-item"&gt;
    &lt;a className="nav-link" href="#"&gt;Link&lt;/a&gt;
  &lt;/li&gt;
  &lt;li className="nav-item"&gt;
    &lt;a className="nav-link disabled" href="#" tabindex="-1" aria-disabled="true"&gt;Disabled&lt;/a&gt;
  &lt;/li&gt;
&lt;/ul&gt;</code></pre>
                                </div>
                            </div>
                        </div>

                        <div className="card">
                            <div className="card-body">
                                <h6 className="card-title">Tabs with dropdowns</h6>
                                <ul className="nav nav-tabs">
                                    <li className="nav-item">
                                        <a className="nav-link active" href="#">Active</a>
                                    </li>
                                    <li className="nav-item dropdown">
                                        <a className="nav-link dropdown-toggle" data-toggle="dropdown" href="#"
                                            role="button" aria-haspopup="true" aria-expanded="false">Dropdown</a>
                                        <div className="dropdown-menu">
                                            <a className="dropdown-item" href="#">Action</a>
                                            <a className="dropdown-item" href="#">Another action</a>
                                            <a className="dropdown-item" href="#">Something else here</a>
                                            <div className="dropdown-divider"></div>
                                            <a className="dropdown-item" href="#">Separated link</a>
                                        </div>
                                    </li>
                                    <li className="nav-item">
                                        <a className="nav-link" href="#">Link</a>
                                    </li>
                                    <li className="nav-item">
                                        <a className="nav-link disabled" href="#" tabindex="-1"
                                            aria-disabled="true">Disabled</a>
                                    </li>
                                </ul>

                                <div data-label="CODE EXAMPLE" className="demo-code-preview">
                                    <pre><code className="language-html">&lt;ul className="nav nav-tabs"&gt;
  &lt;li className="nav-item"&gt;
    &lt;a className="nav-link active" href="#"&gt;Active&lt;/a&gt;
  &lt;/li&gt;
  &lt;li className="nav-item dropdown"&gt;
    &lt;a className="nav-link dropdown-toggle" data-toggle="dropdown" href="#" role="button"
       aria-haspopup="true" aria-expanded="false"&gt;Dropdown&lt;/a&gt;
    &lt;div className="dropdown-menu"&gt;
      &lt;a className="dropdown-item" href="#"&gt;Action&lt;/a&gt;
      &lt;a className="dropdown-item" href="#"&gt;Another action&lt;/a&gt;
      &lt;a className="dropdown-item" href="#"&gt;Something else here&lt;/a&gt;
      &lt;div className="dropdown-divider"&gt;&lt;/div&gt;
      &lt;a className="dropdown-item" href="#"&gt;Separated link&lt;/a&gt;
    &lt;/div&gt;
  &lt;/li&gt;
  &lt;li className="nav-item"&gt;
    &lt;a className="nav-link" href="#"&gt;Link&lt;/a&gt;
  &lt;/li&gt;
  &lt;li className="nav-item"&gt;
    &lt;a className="nav-link disabled" href="#" tabindex="-1" aria-disabled="true"&gt;Disabled&lt;/a&gt;
  &lt;/li&gt;
&lt;/ul&gt;</code></pre>
                                </div>
                            </div>
                        </div>

                        <div className="card">
                            <div className="card-body">
                                <h6 className="card-title">Pills with dropdowns</h6>
                                <ul className="nav nav-pills">
                                    <li className="nav-item">
                                        <a className="nav-link active" href="#">Active</a>
                                    </li>
                                    <li className="nav-item dropdown">
                                        <a className="nav-link dropdown-toggle" data-toggle="dropdown" href="#"
                                            role="button" aria-haspopup="true" aria-expanded="false">Dropdown</a>
                                        <div className="dropdown-menu">
                                            <a className="dropdown-item" href="#">Action</a>
                                            <a className="dropdown-item" href="#">Another action</a>
                                            <a className="dropdown-item" href="#">Something else here</a>
                                            <div className="dropdown-divider"></div>
                                            <a className="dropdown-item" href="#">Separated link</a>
                                        </div>
                                    </li>
                                    <li className="nav-item">
                                        <a className="nav-link" href="#">Link</a>
                                    </li>
                                    <li className="nav-item">
                                        <a className="nav-link disabled" href="#" tabindex="-1"
                                            aria-disabled="true">Disabled</a>
                                    </li>
                                </ul>

                                <div data-label="CODE EXAMPLE" className="demo-code-preview">
                                    <pre><code className="language-html">&lt;ul className="nav nav-pills"&gt;
  &lt;li className="nav-item"&gt;
    &lt;a className="nav-link active" href="#"&gt;Active&lt;/a&gt;
  &lt;/li&gt;
  &lt;li className="nav-item dropdown"&gt;
    &lt;a className="nav-link dropdown-toggle" data-toggle="dropdown" href="#" role="button"
       aria-haspopup="true" aria-expanded="false"&gt;Dropdown&lt;/a&gt;
    &lt;div className="dropdown-menu"&gt;
      &lt;a className="dropdown-item" href="#"&gt;Action&lt;/a&gt;
      &lt;a className="dropdown-item" href="#"&gt;Another action&lt;/a&gt;
      &lt;a className="dropdown-item" href="#"&gt;Something else here&lt;/a&gt;
      &lt;div className="dropdown-divider"&gt;&lt;/div&gt;
      &lt;a className="dropdown-item" href="#"&gt;Separated link&lt;/a&gt;
    &lt;/div&gt;
  &lt;/li&gt;
  &lt;li className="nav-item"&gt;
    &lt;a className="nav-link" href="#"&gt;Link&lt;/a&gt;
  &lt;/li&gt;
  &lt;li className="nav-item"&gt;
    &lt;a className="nav-link disabled" href="#" tabindex="-1" aria-disabled="true"&gt;Disabled&lt;/a&gt;
  &lt;/li&gt;
&lt;/ul&gt;</code></pre>
                                </div>
                            </div>
                        </div>

                    </div>
                </div> 

            </div>

        </main>
        {/* <!-- end::main-content --> */}

        {/* <!-- begin::footer --> */}
        <footer>
            <div className="container">
                <div>© 2019 Protable v1.0.0 Made by <a href="http://laborasyon.com">Laborasyon</a></div>
                <div>
                    <nav className="nav">
                        <a href="https://themeforest.net/licenses/standard" className="nav-link">Licenses</a>
                        <a href="#" className="nav-link">Change Log</a>
                        <a href="#" className="nav-link">Get Help</a>
                    </nav>
                </div>
            </div>
        </footer>
        {/* <!-- end::footer --> */}

    </div>
    {/* <!-- end::main --> */}
    </div>
  )
}

export default Home