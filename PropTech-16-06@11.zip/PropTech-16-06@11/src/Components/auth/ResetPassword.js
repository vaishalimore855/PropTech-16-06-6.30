import React from 'react';
import { useNavigate } from "react-router-dom";
import Login from './login';
const ResetPassword = () => {
    var navigate = useNavigate()
    const handleClick = () => {
        navigate("/");
    };
    return (
        <div>
            <div class="form-wrapper">
                {/* <!-- logo --> */}
                <div id="logo">
                    <h2>PropTech</h2>
                </div>
                {/* <!-- ./ logo --> */}
                <h5>Reset password</h5>

                {/* <!-- form --> */}
                <form>
                    <div class="form-group">
                        <input type="text" class="form-control" placeholder="Username or email" required autofocus />
                    </div>
                    <button class="btn btn-primary btn-block">Submit</button>
                    <hr />
                    <p class="text-muted">Take a different action.</p>

                    <a href="./register.html" class="btn btn-sm btn-outline-light mr-1" style={{ display: "flex", justifyContent: "center", alignItems: 'center' }}>Register now!</a>
                    <span style={{ display: "flex", justifyContent: "center", alignItems: 'center' }}>or</span>
                    <a href="" class="btn btn-sm btn-outline-light ml-1" style={{ display: "flex", justifyContent: "center", alignItems: 'center' }} onClick={()=>handleClick()} >Login!</a>
                </form>
                {/* <!-- ./ form --> */}

            </div>


        </div>

    );
}

export default ResetPassword;
