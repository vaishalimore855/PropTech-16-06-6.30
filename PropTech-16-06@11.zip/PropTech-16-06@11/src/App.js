import logo from './logo.svg';
// import './App.css';
// import './App.min.css';
import './assets/css/custom.css'
import './assets/css/app.css'
// import './assets/css/app.min.css'
import './assets/css/RealCustom.css'
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Login from './Components/auth/login';
import Profile from './Components/admin/Profile';
import Sidebar from './Components/Sidebar/Sidebar';
import Home from './Components/admin/home';
import ResetPassword from './Components/auth/ResetPassword';
import SweetAlert from './Components/admin/SweetAlert';
import AddBuyer from './Components/admin/AddBuyer';
import Header from './Components/admin/Header';
import Footer from './Components/admin/Footer';
function App() {
  return (
    <BrowserRouter>
      {/* <Login/> */}
      <Routes>
        <Route path="/" exact element={<Login />}></Route>
        <Route path="/header" exact element={<Header />}></Route>
        <Route path="footer" exact element={<Footer />}></Route>
        <Route path="/reset-password" element={<ResetPassword />}></Route>
        <Route path="/profile" element={<Profile />}></Route>
        <Route path="/sweetalert" element={<SweetAlert />}></Route>
        <Route path="/add-buyer" element={<AddBuyer />}></Route>
        <Route path="sidebar/" element={<Sidebar />}></Route>
        <Route path="/homepage" element={<Home />}></Route>


      </Routes>
    </BrowserRouter>
  );
}

export default App;
